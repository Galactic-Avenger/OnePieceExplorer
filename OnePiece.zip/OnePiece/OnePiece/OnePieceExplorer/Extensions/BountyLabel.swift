import UIKit

// BountyLabel  (UILabel subclass)

final class BountyLabel: UILabel {

    enum Style {
        case full   // 3,000,000,000 ฿  — for detail screen
        case short  // 3B ฿             — for cards & leaderboard
    }

    var style: Style = .short 

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        font          = UIFont.monospacedSystemFont(ofSize: 14, weight: .semibold)
        textColor     = UIColor(red: 0.94, green: 0.62, blue: 0.09, alpha: 1)
        textAlignment = .right
        adjustsFontSizeToFitWidth = true
        minimumScaleFactor        = 0.6
    }

    // Set from Character model
    func setBounty(_ character: Character) {
        switch style {
        case .full:  text = character.bountyFormatted
        case .short: text = character.bountyShort
        }
    }

    // Set from raw string (fallback)
    func setBounty(_ bountyString: String?) {
        guard let str = bountyString, !str.isEmpty else {
            text = "Unknown ฿"; return
        }
        let digits = str.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        guard let value = Int(digits), value > 0 else {
            text = "Unknown ฿"; return
        }
        switch style {
        case .full:
            let formatter        = NumberFormatter()
            formatter.numberStyle       = .decimal
            formatter.groupingSeparator = ","
            text = "\(formatter.string(from: NSNumber(value: value)) ?? str) ฿"
        case .short:
            switch value {
            case 1_000_000_000...: text = String(format: "%.2gB ฿", Double(value) / 1_000_000_000)
            case 1_000_000...:     text = "\(value / 1_000_000)M ฿"
            case 1_000...:         text = "\(value / 1_000)K ฿"
            default:               text = "\(value) ฿"
            }
        }
    }
}
