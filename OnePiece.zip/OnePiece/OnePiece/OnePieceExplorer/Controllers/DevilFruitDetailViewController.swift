import UIKit

// DevilFruitDetailViewController
// Detailed page for a single Devil Fruit — big image, type badge, current/previous
// owners, meaning, description, debut. Mirrors the character detail layout.

final class DevilFruitDetailViewController: UIViewController {

    private let fruit: DevilFruit

    init(fruit: DevilFruit) {
        self.fruit = fruit
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    // UI
    private let scrollView   = UIScrollView()
    private let contentView  = UIView()
    private let heroView     = UIView()
    private let fruitImage   = UIImageView()
    private let initialsLbl  = UILabel()
    private let typeChip     = PaddedLabel()
    private let nameLabel    = UILabel()
    private let japaneseLbl  = UILabel()
    private let meaningLbl   = UILabel()
    private let infoCard     = UIView()
    private let currentLbl   = UILabel()
    private let previousLbl  = UILabel()
    private let debutLbl     = UILabel()
    private let descCard     = UIView()
    private let descLabel    = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Devil Fruit"
        Theme.applyNavBar(to: navigationController)
        view.backgroundColor = Theme.pageBG
        setupViews()
        populate()
        loadImage()
    }

    private func setupViews() {
        scrollView.alwaysBounceVertical = true
        scrollView.translatesAutoresizingMaskIntoConstraints  = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        // Hero with the fruit image
        heroView.backgroundColor = Theme.cardBG
        heroView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(heroView)

        fruitImage.contentMode = .scaleAspectFit
        fruitImage.clipsToBounds = true
        fruitImage.translatesAutoresizingMaskIntoConstraints = false
        heroView.addSubview(fruitImage)

        initialsLbl.font = .systemFont(ofSize: 60, weight: .heavy)
        initialsLbl.textColor = UIColor.white.withAlphaComponent(0.2)
        initialsLbl.textAlignment = .center
        initialsLbl.translatesAutoresizingMaskIntoConstraints = false
        heroView.addSubview(initialsLbl)

        typeChip.font                = .systemFont(ofSize: 11, weight: .heavy)
        typeChip.textColor           = .white
        typeChip.layer.cornerRadius  = 8
        typeChip.layer.masksToBounds = true
        typeChip.padding             = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
        typeChip.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(typeChip)

        nameLabel.font          = .systemFont(ofSize: 26, weight: .heavy)
        nameLabel.textColor     = .white
        nameLabel.textAlignment = .center
        nameLabel.adjustsFontSizeToFitWidth = true
        nameLabel.minimumScaleFactor        = 0.6
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(nameLabel)

        japaneseLbl.font          = .systemFont(ofSize: 14)
        japaneseLbl.textColor     = UIColor.white.withAlphaComponent(0.5)
        japaneseLbl.textAlignment = .center
        japaneseLbl.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(japaneseLbl)

        meaningLbl.font          = .italicSystemFont(ofSize: 13)
        meaningLbl.textColor     = Theme.gold.withAlphaComponent(0.85)
        meaningLbl.textAlignment = .center
        meaningLbl.numberOfLines = 0
        meaningLbl.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(meaningLbl)

        // Info card
        infoCard.backgroundColor    = Theme.cardBG
        infoCard.layer.cornerRadius = 14
        infoCard.layer.borderWidth  = 0.5
        infoCard.layer.borderColor  = UIColor.white.withAlphaComponent(0.08).cgColor
        infoCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(infoCard)

        let rows: [(String, UILabel)] = [
            ("Current Owner",  currentLbl),
            ("Previous Owner", previousLbl),
            ("Usage Debut",    debutLbl),
        ]
        let stack = UIStackView()
        stack.axis = .vertical
        stack.translatesAutoresizingMaskIntoConstraints = false
        infoCard.addSubview(stack)
        rows.enumerated().forEach { i, pair in
            stack.addArrangedSubview(makeRow(title: pair.0, valueLabel: pair.1, isLast: i == rows.count - 1))
        }

        // Description card
        descCard.backgroundColor    = Theme.cardBG
        descCard.layer.cornerRadius = 14
        descCard.layer.borderWidth  = 0.5
        descCard.layer.borderColor  = UIColor.white.withAlphaComponent(0.08).cgColor
        descCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(descCard)

        let descTitle       = UILabel()
        descTitle.text      = "DESCRIPTION"
        descTitle.font      = .systemFont(ofSize: 12, weight: .heavy)
        descTitle.textColor = Theme.gold
        descTitle.translatesAutoresizingMaskIntoConstraints = false
        descCard.addSubview(descTitle)

        descLabel.font          = .systemFont(ofSize: 14)
        descLabel.textColor     = UIColor.white.withAlphaComponent(0.78)
        descLabel.numberOfLines = 0
        descLabel.translatesAutoresizingMaskIntoConstraints = false
        descCard.addSubview(descLabel)

        // Constraints
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),

            heroView.topAnchor.constraint(equalTo: contentView.topAnchor),
            heroView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            heroView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            heroView.heightAnchor.constraint(equalToConstant: 260),

            fruitImage.centerXAnchor.constraint(equalTo: heroView.centerXAnchor),
            fruitImage.centerYAnchor.constraint(equalTo: heroView.centerYAnchor),
            fruitImage.widthAnchor.constraint(equalToConstant: 200),
            fruitImage.heightAnchor.constraint(equalToConstant: 200),

            initialsLbl.centerXAnchor.constraint(equalTo: heroView.centerXAnchor),
            initialsLbl.centerYAnchor.constraint(equalTo: heroView.centerYAnchor),

            typeChip.topAnchor.constraint(equalTo: heroView.bottomAnchor, constant: 14),
            typeChip.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),

            nameLabel.topAnchor.constraint(equalTo: typeChip.bottomAnchor, constant: 10),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),

            japaneseLbl.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            japaneseLbl.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            japaneseLbl.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),

            meaningLbl.topAnchor.constraint(equalTo: japaneseLbl.bottomAnchor, constant: 6),
            meaningLbl.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 32),
            meaningLbl.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -32),

            infoCard.topAnchor.constraint(equalTo: meaningLbl.bottomAnchor, constant: 18),
            infoCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            infoCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            stack.topAnchor.constraint(equalTo: infoCard.topAnchor, constant: 4),
            stack.leadingAnchor.constraint(equalTo: infoCard.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: infoCard.trailingAnchor),
            stack.bottomAnchor.constraint(equalTo: infoCard.bottomAnchor, constant: -4),

            descCard.topAnchor.constraint(equalTo: infoCard.bottomAnchor, constant: 14),
            descCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            descCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            descCard.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -32),

            descTitle.topAnchor.constraint(equalTo: descCard.topAnchor, constant: 14),
            descTitle.leadingAnchor.constraint(equalTo: descCard.leadingAnchor, constant: 16),
            descTitle.trailingAnchor.constraint(equalTo: descCard.trailingAnchor, constant: -16),

            descLabel.topAnchor.constraint(equalTo: descTitle.bottomAnchor, constant: 8),
            descLabel.leadingAnchor.constraint(equalTo: descCard.leadingAnchor, constant: 16),
            descLabel.trailingAnchor.constraint(equalTo: descCard.trailingAnchor, constant: -16),
            descLabel.bottomAnchor.constraint(equalTo: descCard.bottomAnchor, constant: -14),
        ])
    }

    private func makeRow(title: String, valueLabel: UILabel, isLast: Bool) -> UIView {
        let container  = UIView()
        let titleLabel = UILabel()
        titleLabel.text      = title
        titleLabel.font      = .systemFont(ofSize: 14)
        titleLabel.textColor = UIColor.white.withAlphaComponent(0.55)

        valueLabel.font          = .systemFont(ofSize: 14, weight: .semibold)
        valueLabel.textColor     = .white
        valueLabel.textAlignment = .right
        valueLabel.numberOfLines = 2

        let sep = UIView()
        sep.backgroundColor = UIColor.white.withAlphaComponent(0.07)
        sep.isHidden = isLast

        [titleLabel, valueLabel, sep].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview($0)
        }
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 14),
            titleLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            titleLabel.bottomAnchor.constraint(equalTo: container.bottomAnchor, constant: -14),
            titleLabel.widthAnchor.constraint(equalToConstant: 130),

            valueLabel.centerYAnchor.constraint(equalTo: titleLabel.centerYAnchor),
            valueLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            valueLabel.leadingAnchor.constraint(equalTo: titleLabel.trailingAnchor, constant: 8),

            sep.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            sep.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            sep.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            sep.heightAnchor.constraint(equalToConstant: 0.5),
        ])
        return container
    }

    private func populate() {
        nameLabel.text   = fruit.name
        japaneseLbl.text = fruit.japaneseName ?? ""
        meaningLbl.text  = fruit.meaning.map { "\u{201C}\($0)\u{201D}" } ?? ""

        typeChip.text  = "  " + (fruit.type ?? "Unknown").uppercased() + "  "
        typeChip.backgroundColor = fruit.typeBadgeColor()

        currentLbl.text  = fruit.currentOwner?.isEmpty  == false ? fruit.currentOwner!  : "Unknown"
        previousLbl.text = fruit.previousOwner?.isEmpty == false ? fruit.previousOwner! : "—"
        debutLbl.text    = fruit.usageDebut?.isEmpty    == false ? fruit.usageDebut!    : "Unknown"

        if let desc = fruit.description, !desc.isEmpty {
            descLabel.text      = desc
            descLabel.textColor = UIColor.white.withAlphaComponent(0.78)
        } else {
            descLabel.text      = "No description available."
            descLabel.textColor = UIColor.white.withAlphaComponent(0.35)
        }

        initialsLbl.text = String(fruit.name.prefix(1))
    }

    private func loadImage() {
        guard let urlStr = fruit.avatarSrc, let url = URL(string: urlStr) else { return }
        if let cached = ImageCache.shared.image(for: url) {
            fruitImage.image     = cached
            initialsLbl.isHidden = true
            return
        }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let img = UIImage(data: data) else { return }
            ImageCache.shared.store(img, for: url)
            DispatchQueue.main.async {
                self?.fruitImage.image     = img
                self?.initialsLbl.isHidden = true
            }
        }.resume()
    }
}
