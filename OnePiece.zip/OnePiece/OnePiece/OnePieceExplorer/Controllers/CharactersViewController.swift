import UIKit

//CharactersViewController  (Screen 1)
// Now acts as a multi-mode browser. The top pill scroll lets you switch between:
//   - All Characters (default grid)
//   - Crews (browser of crew cards → tap to see members)
//   - Devil Fruits (browser of fruits → tap to see fruit detail)
//
// Each mode swaps in a different child view controller below the search bar.

final class CharactersViewController: UIViewController {

    // Browser modes
    private enum BrowseMode: Int {
        case all, crews, fruits
        var title: String {
            switch self {
            case .all:    return "Characters"
            case .crews:  return "Crews"
            case .fruits: return "Devil Fruits"
            }
        }
    }
    private var currentMode: BrowseMode = .all

    // Data (for the "All Characters" mode)
    private var allCharacters:      [Character] = []
    private var filteredCharacters: [Character] = []
    private var currentPage         = 1
    private var isLoadingMore       = false

    // Card-expand transition (only used in "all" mode)
    private var pendingTransition: CardExpandTransition?

    // Child VCs used for the crews/fruits modes
    private var crewsVC: CrewsViewController?
    private var fruitsVC: DevilFruitsViewController?

    // UI
    private lazy var searchBar: UISearchBar = {
        let sb = UISearchBar()
        sb.placeholder    = "Search..."
        sb.barStyle       = .black
        sb.searchBarStyle = .minimal
        sb.delegate       = self
        sb.tintColor      = Theme.gold
        sb.searchTextField.textColor       = .white
        sb.searchTextField.backgroundColor = UIColor.white.withAlphaComponent(0.08)
        return sb
    }()

    // Horizontal pill scroll for switching modes (Characters / Crews / Devil Fruits)
    private lazy var modeScroll: UIScrollView = {
        let sv = UIScrollView()
        sv.showsHorizontalScrollIndicator = false
        sv.contentInset                   = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        sv.isDirectionalLockEnabled       = true
        return sv
    }()
    private let modeStack: UIStackView = {
        let sv = UIStackView()
        sv.axis    = .horizontal
        sv.spacing = 8
        return sv
    }()

    // Container where the active mode's content lives
    private let contentContainer = UIView()

    // Mode 1: collection view of characters
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 12
        layout.minimumLineSpacing      = 14
        layout.sectionInset            = UIEdgeInsets(top: 12, left: 14, bottom: 20, right: 14)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.backgroundColor      = Theme.pageBG
        cv.alwaysBounceVertical = true
        cv.keyboardDismissMode  = .onDrag
        cv.register(CharacterCardCell.self, forCellWithReuseIdentifier: CharacterCardCell.reuseID)
        cv.dataSource = self
        cv.delegate   = self
        let refresh = UIRefreshControl()
        refresh.tintColor = Theme.gold
        refresh.addTarget(self, action: #selector(handleRefresh), for: .valueChanged)
        cv.refreshControl = refresh
        return cv
    }()

    private let offlineBanner: UILabel = {
        let lbl = UILabel()
        lbl.text            = "⚠️  No internet connection"
        lbl.textColor       = .white
        lbl.backgroundColor = UIColor(red:0.64, green:0.18, blue:0.18, alpha:1)
        lbl.textAlignment   = .center
        lbl.font            = .systemFont(ofSize: 13, weight: .medium)
        lbl.isHidden        = true
        return lbl
    }()

    private let loadingIndicator: UIActivityIndicatorView = {
        let ai = UIActivityIndicatorView(style: .large)
        ai.color = Theme.gold
        ai.hidesWhenStopped = true
        return ai
    }()

    private var offlineBannerHeight: NSLayoutConstraint!

    // Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationBar()
        setupViews()
        setupNetworkMonitor()
        buildModePills()
        switchToMode(.all, initial: true)
        fetchCharacters()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if currentMode == .all { collectionView.reloadData() }
        navigationController?.delegate = self
    }

    // Nav bar
    private func setupNavigationBar() {
        title = "Explorer"
        navigationController?.navigationBar.prefersLargeTitles = true
        Theme.applyNavBar(to: navigationController)

        let diceBtn = UIBarButtonItem(image: UIImage(systemName: "dice.fill"),
                                      style: .plain, target: self,
                                      action: #selector(randomCharacterTapped))
        diceBtn.tintColor = Theme.gold
        navigationItem.rightBarButtonItem = diceBtn
    }

    // Layout
    private func setupViews() {
        view.backgroundColor = Theme.pageBG

        [offlineBanner, searchBar, modeScroll, contentContainer, loadingIndicator].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview($0)
        }

        modeScroll.addSubview(modeStack)
        modeStack.translatesAutoresizingMaskIntoConstraints = false
        offlineBannerHeight = offlineBanner.heightAnchor.constraint(equalToConstant: 0)

        // Default content view = collection view of characters
        contentContainer.addSubview(collectionView)
        collectionView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            offlineBanner.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            offlineBanner.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            offlineBanner.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            offlineBannerHeight,

            searchBar.topAnchor.constraint(equalTo: offlineBanner.bottomAnchor),
            searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            modeScroll.topAnchor.constraint(equalTo: searchBar.bottomAnchor, constant: 4),
            modeScroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            modeScroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            modeScroll.heightAnchor.constraint(equalToConstant: 40),

            modeStack.topAnchor.constraint(equalTo: modeScroll.topAnchor),
            modeStack.leadingAnchor.constraint(equalTo: modeScroll.leadingAnchor),
            modeStack.trailingAnchor.constraint(equalTo: modeScroll.trailingAnchor),
            modeStack.heightAnchor.constraint(equalTo: modeScroll.heightAnchor),

            contentContainer.topAnchor.constraint(equalTo: modeScroll.bottomAnchor, constant: 4),
            contentContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            contentContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            contentContainer.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            collectionView.topAnchor.constraint(equalTo: contentContainer.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: contentContainer.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: contentContainer.bottomAnchor),

            loadingIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        ])
    }

    // Mode pills
    private func buildModePills() {
        modeStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        [BrowseMode.all, .crews, .fruits].forEach { mode in
            let btn = makeModeButton(title: mode.title, isActive: mode == currentMode)
            btn.tag = mode.rawValue
            btn.addTarget(self, action: #selector(modeButtonTapped(_:)), for: .touchUpInside)
            modeStack.addArrangedSubview(btn)
        }
    }

    private func makeModeButton(title: String, isActive: Bool) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font   = .systemFont(ofSize: 13, weight: .semibold)
        btn.layer.cornerRadius = 16
        btn.layer.borderWidth  = 1
        var config = UIButton.Configuration.plain()
        config.contentInsets = NSDirectionalEdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16)
        btn.configuration = config
        applyPillStyle(btn, isActive: isActive)
        return btn
    }

    private func applyPillStyle(_ btn: UIButton, isActive: Bool) {
        btn.backgroundColor   = isActive ? Theme.gold : UIColor.white.withAlphaComponent(0.07)
        btn.tintColor         = isActive ? UIColor(red:0.1, green:0.1, blue:0.1, alpha:1)
                                         : UIColor.white.withAlphaComponent(0.7)
        btn.layer.borderColor = isActive ? Theme.gold.cgColor
                                         : UIColor.white.withAlphaComponent(0.2).cgColor
    }

    @objc private func modeButtonTapped(_ sender: UIButton) {
        guard let mode = BrowseMode(rawValue: sender.tag) else { return }
        switchToMode(mode, initial: false)
    }

    // Switch modes
    private func switchToMode(_ mode: BrowseMode, initial: Bool) {
        currentMode = mode

        // Update pill states
        modeStack.arrangedSubviews.compactMap { $0 as? UIButton }.forEach { btn in
            applyPillStyle(btn, isActive: btn.tag == mode.rawValue)
        }

        // Clear current child VC content (except the collectionView which is owned by self)
        contentContainer.subviews.forEach { sv in
            if sv !== collectionView { sv.removeFromSuperview() }
        }
        // Detach any child VCs
        children.forEach {
            $0.willMove(toParent: nil)
            $0.view.removeFromSuperview()
            $0.removeFromParent()
        }

        switch mode {
        case .all:
            // Show our own collection view
            collectionView.isHidden = false
            if !initial { collectionView.reloadData() }
        case .crews:
            collectionView.isHidden = true
            let vc = CrewsViewController()
            addChild(vc)
            vc.view.translatesAutoresizingMaskIntoConstraints = false
            contentContainer.addSubview(vc.view)
            NSLayoutConstraint.activate([
                vc.view.topAnchor.constraint(equalTo: contentContainer.topAnchor),
                vc.view.leadingAnchor.constraint(equalTo: contentContainer.leadingAnchor),
                vc.view.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor),
                vc.view.bottomAnchor.constraint(equalTo: contentContainer.bottomAnchor),
            ])
            vc.didMove(toParent: self)
            crewsVC = vc
        case .fruits:
            collectionView.isHidden = true
            let vc = DevilFruitsViewController()
            addChild(vc)
            vc.view.translatesAutoresizingMaskIntoConstraints = false
            contentContainer.addSubview(vc.view)
            NSLayoutConstraint.activate([
                vc.view.topAnchor.constraint(equalTo: contentContainer.topAnchor),
                vc.view.leadingAnchor.constraint(equalTo: contentContainer.leadingAnchor),
                vc.view.trailingAnchor.constraint(equalTo: contentContainer.trailingAnchor),
                vc.view.bottomAnchor.constraint(equalTo: contentContainer.bottomAnchor),
            ])
            vc.didMove(toParent: self)
            fruitsVC = vc
        }
    }

    // Network monitor
    private func setupNetworkMonitor() {
        NotificationCenter.default.addObserver(self,
            selector: #selector(connectivityChanged(_:)),
            name: NetworkMonitor.connectivityChanged, object: nil)
    }

    @objc private func connectivityChanged(_ n: Notification) {
        showOfflineBanner(!(n.object as? Bool ?? true))
    }

    private func showOfflineBanner(_ show: Bool) {
        offlineBannerHeight.constant = show ? 36 : 0
        UIView.animate(withDuration: 0.3) { self.view.layoutIfNeeded() }
        offlineBanner.isHidden = !show
    }

    // Fetch characters
    private func fetchCharacters() {
        if currentPage == 1 { loadingIndicator.startAnimating() }
        APIService.shared.fetchCharacters(page: currentPage) { [weak self] result in
            DispatchQueue.main.async {
                self?.loadingIndicator.stopAnimating()
                self?.collectionView.refreshControl?.endRefreshing()
                switch result {
                case .success(let chars):
                    let existingIDs = Set(self?.allCharacters.map { $0.id } ?? [])
                    let newChars    = chars.filter { !existingIDs.contains($0.id) }
                    self?.allCharacters.append(contentsOf: newChars)
                    self?.applyFilter()
                case .failure(let err):
                    self?.showError(err.localizedDescription)
                }
                self?.isLoadingMore = false
            }
        }
    }

    private func applyFilter(searchText: String = "") {
        var results = allCharacters
        if !searchText.isEmpty {
            results = results.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        }
        filteredCharacters = results
        collectionView.reloadData()
    }

    // Actions
    @objc private func handleRefresh() {
        currentPage   = 1
        allCharacters = []
        fetchCharacters()
    }

    @objc private func randomCharacterTapped() {
        APIService.shared.fetchRandomCharacter { [weak self] result in
            DispatchQueue.main.async {
                if case .success(let char) = result {
                    let detail = CharacterDetailViewController(character: char)
                    self?.navigationController?.pushViewController(detail, animated: true)
                }
            }
        }
    }

    private func showError(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    // Push detail with card-expand transition
    private func pushDetail(for character: Character, from cell: CharacterCardCell?) {
        if let cell = cell, let window = cell.window {
            let frame = cell.convert(cell.bounds, to: window)
            let snap  = cell.snapshotImage()
            pendingTransition = CardExpandTransition(sourceFrame: frame, sourceImage: snap)
        }
        let detail = CharacterDetailViewController(character: character)
        navigationController?.pushViewController(detail, animated: true)
    }
}

// UICollectionViewDataSource

extension CharactersViewController: UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int {
        filteredCharacters.count
    }
    func collectionView(_ cv: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: CharacterCardCell.reuseID,
                                           for: indexPath) as! CharacterCardCell
        cell.configure(with: filteredCharacters[indexPath.item])
        return cell
    }
}

// UICollectionViewDelegate

extension CharactersViewController: UICollectionViewDelegate {
    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = cv.cellForItem(at: indexPath) as? CharacterCardCell
        pushDetail(for: filteredCharacters[indexPath.item], from: cell)
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // Only paginate when we're in the All characters mode
        guard currentMode == .all, scrollView === collectionView else { return }
        let offset    = scrollView.contentOffset.y
        let height    = scrollView.contentSize.height
        let threshold = height - scrollView.frame.height - 200
        if offset > threshold && !isLoadingMore && allCharacters.count > 0 {
            isLoadingMore = true
            currentPage  += 1
            fetchCharacters()
        }
    }

    func collectionView(_ cv: UICollectionView,
                        contextMenuConfigurationForItemAt indexPath: IndexPath,
                        point: CGPoint) -> UIContextMenuConfiguration? {
        let char  = filteredCharacters[indexPath.item]
        let isFav = PlistService.shared.isFavorite(id: char.id)
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let action = UIAction(
                title: isFav ? "Remove from Favorites" : "Add to Favorites",
                image: UIImage(systemName: isFav ? "star.slash.fill" : "star.fill"),
                attributes: isFav ? .destructive : []) { _ in
                    PlistService.shared.toggleFavorite(id: char.id)
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            }
            return UIMenu(title: char.name, children: [action])
        }
    }
}

//  UICollectionViewDelegateFlowLayout

extension CharactersViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ cv: UICollectionView, layout _: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding: CGFloat = 14 * 2 + 12
        let width            = (cv.bounds.width - padding) / 2
        return CGSize(width: width, height: width * 1.45)
    }
}

// UISearchBarDelegate

extension CharactersViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // Local filter immediately for snappy feedback
        if searchText.isEmpty { applyFilter() }
        else {
            applyFilter(searchText: searchText)
            // Debounce API search
            NSObject.cancelPreviousPerformRequests(withTarget: self,
                selector: #selector(performAPISearch), object: nil)
            perform(#selector(performAPISearch), with: nil, afterDelay: 0.5)
        }
    }

    @objc private func performAPISearch() {
        guard let query = searchBar.text, !query.isEmpty, currentMode == .all else { return }
        PlistService.shared.saveSearchQuery(query)
        APIService.shared.searchCharacters(name: query) { [weak self] result in
            DispatchQueue.main.async {
                if case .success(let chars) = result, !chars.isEmpty {
                    self?.filteredCharacters = chars
                    self?.collectionView.reloadData()
                }
            }
        }
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) { searchBar.resignFirstResponder() }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""; searchBar.resignFirstResponder(); applyFilter()
    }
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
    }
}

//  UINavigationControllerDelegate

extension CharactersViewController: UINavigationControllerDelegate {
    func navigationController(_ navigationController: UINavigationController,
                              animationControllerFor operation: UINavigationController.Operation,
                              from fromVC: UIViewController,
                              to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        guard operation == .push, let transition = pendingTransition else { return nil }
        pendingTransition = nil
        return transition
    }
}
