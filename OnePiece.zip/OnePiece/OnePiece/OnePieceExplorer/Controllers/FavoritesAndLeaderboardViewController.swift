import UIKit

// FavoritesViewController  (Screen 3)

final class FavoritesViewController: UIViewController {

    private var favoriteCharacters: [Character] = []
    private var pendingTransition: CardExpandTransition?

    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 12
        layout.minimumLineSpacing      = 14
        layout.sectionInset            = UIEdgeInsets(top: 16, left: 14, bottom: 20, right: 14)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.backgroundColor      = Theme.pageBG
        cv.alwaysBounceVertical = true
        cv.register(CharacterCardCell.self, forCellWithReuseIdentifier: CharacterCardCell.reuseID)
        cv.dataSource = self
        cv.delegate   = self
        cv.translatesAutoresizingMaskIntoConstraints = false
        return cv
    }()

    private lazy var emptyStateView: UIView = {
        let v = UIView()
        v.isHidden = true
        v.translatesAutoresizingMaskIntoConstraints = false

        let icon        = UILabel()
        icon.text       = "☆"
        icon.font       = .systemFont(ofSize: 60)
        icon.textColor  = UIColor.white.withAlphaComponent(0.15)
        icon.textAlignment = .center

        let title       = UILabel()
        title.text      = "No favorites yet"
        title.font      = .systemFont(ofSize: 18, weight: .semibold)
        title.textColor = UIColor.white.withAlphaComponent(0.4)
        title.textAlignment = .center

        let sub         = UILabel()
        sub.text        = "Long press any character card\nto quickly save it here."
        sub.font        = .systemFont(ofSize: 14)
        sub.textColor   = UIColor.white.withAlphaComponent(0.25)
        sub.textAlignment = .center
        sub.numberOfLines = 0

        let stack       = UIStackView(arrangedSubviews: [icon, title, sub])
        stack.axis      = .vertical
        stack.spacing   = 10
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: v.centerYAnchor, constant: -40),
            stack.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 32),
            stack.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -32),
        ])
        return v
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavBar()
        setupViews()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadFavorites()
        navigationController?.delegate = self
    }

    private func setupNavBar() {
        title = "Favorites"
        navigationController?.navigationBar.prefersLargeTitles = true
        Theme.applyNavBar(to: navigationController)
    }

    private func setupViews() {
        view.backgroundColor = Theme.pageBG
        view.addSubview(collectionView)
        view.addSubview(emptyStateView)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            emptyStateView.topAnchor.constraint(equalTo: view.topAnchor),
            emptyStateView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            emptyStateView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            emptyStateView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }

    private func loadFavorites() {
        let ids = PlistService.shared.loadFavoriteIDs()
        guard !ids.isEmpty else {
            favoriteCharacters = []
            collectionView.reloadData()
            emptyStateView.isHidden = false
            collectionView.isHidden = true
            return
        }

        emptyStateView.isHidden = true
        collectionView.isHidden = false

        var loaded: [Character] = []
        let group = DispatchGroup()

        ids.forEach { id in
            group.enter()
            APIService.shared.fetchCharacter(id: id) { result in
                if case .success(let char) = result { loaded.append(char) }
                group.leave()
            }
        }

        group.notify(queue: .main) { [weak self] in
            self?.favoriteCharacters = ids.compactMap { id in loaded.first { $0.id == id } }
            self?.collectionView.reloadData()
        }
    }
}

extension FavoritesViewController: UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int {
        favoriteCharacters.count
    }
    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: CharacterCardCell.reuseID,
                                           for: indexPath) as! CharacterCardCell
        cell.configure(with: favoriteCharacters[indexPath.item])
        return cell
    }
}

extension FavoritesViewController: UICollectionViewDelegate {
    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = cv.cellForItem(at: indexPath) as? CharacterCardCell
        if let cell = cell, let window = cell.window {
            let frame = cell.convert(cell.bounds, to: window)
            pendingTransition = CardExpandTransition(sourceFrame: frame, sourceImage: cell.snapshotImage())
        }
        let detail = CharacterDetailViewController(character: favoriteCharacters[indexPath.item])
        navigationController?.pushViewController(detail, animated: true)
    }

    func collectionView(_ cv: UICollectionView,
                        contextMenuConfigurationForItemAt indexPath: IndexPath,
                        point: CGPoint) -> UIContextMenuConfiguration? {
        let char = favoriteCharacters[indexPath.item]
        return UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            let remove = UIAction(title: "Remove from Favorites",
                                  image: UIImage(systemName: "star.slash.fill"),
                                  attributes: .destructive) { [weak self] _ in
                PlistService.shared.removeFavorite(id: char.id)
                self?.loadFavorites()
            }
            return UIMenu(title: char.name, children: [remove])
        }
    }
}

extension FavoritesViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ cv: UICollectionView,
                        layout _: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding: CGFloat = 14 * 2 + 12
        let width            = (cv.bounds.width - padding) / 2
        return CGSize(width: width, height: width * 1.35)
    }
}

extension FavoritesViewController: UINavigationControllerDelegate {
    func navigationController(_ nc: UINavigationController,
                              animationControllerFor operation: UINavigationController.Operation,
                              from: UIViewController, to: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        guard operation == .push, let t = pendingTransition else { return nil }
        pendingTransition = nil
        return t
    }
}

// ─────────────────────────────────────────────────────────────────────────────

// LeaderboardViewController  (Screen 4 — Wanted Wall)

final class LeaderboardViewController: UIViewController {

    private var characters: [Character] = []

    private lazy var collectionView: UICollectionView = {
        let cv = UICollectionView(frame: .zero, collectionViewLayout: WantedPosterWallLayout())
        cv.backgroundColor      = Theme.pageBG
        cv.alwaysBounceVertical = true
        cv.contentInset         = UIEdgeInsets(top: 4, left: 0, bottom: 30, right: 0)
        cv.register(WantedPosterCell.self, forCellWithReuseIdentifier: WantedPosterCell.reuseID)
        cv.dataSource = self
        cv.delegate   = self
        cv.translatesAutoresizingMaskIntoConstraints = false
        return cv
    }()

    private let loadingIndicator: UIActivityIndicatorView = {
        let ai = UIActivityIndicatorView(style: .large)
        ai.color = Theme.gold
        ai.hidesWhenStopped = true
        ai.translatesAutoresizingMaskIntoConstraints = false
        return ai
    }()

    private let bountyBoardLabel: UILabel = {
        let lbl = UILabel()
        lbl.text          = "MOST WANTED"
        lbl.font          = .systemFont(ofSize: 11, weight: .heavy)
        lbl.textColor     = UIColor.white.withAlphaComponent(0.35)
        lbl.textAlignment = .center
        lbl.translatesAutoresizingMaskIntoConstraints = false
        return lbl
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavBar()
        setupViews()
        fetchLeaderboard()
    }

    private func setupNavBar() {
        title = "Wanted"
        navigationController?.navigationBar.prefersLargeTitles = true
        Theme.applyNavBar(to: navigationController)
    }

    private func setupViews() {
        view.backgroundColor = Theme.pageBG
        view.addSubview(bountyBoardLabel)
        view.addSubview(collectionView)
        view.addSubview(loadingIndicator)
        NSLayoutConstraint.activate([
            bountyBoardLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 6),
            bountyBoardLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            collectionView.topAnchor.constraint(equalTo: bountyBoardLabel.bottomAnchor, constant: 6),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            loadingIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        ])
    }

    private func fetchLeaderboard() {
        // Seed with placeholders for the full top 25 in canonical order so the
        // wall renders immediately. Each canonical name then gets an API search
        // in parallel; matches replace the placeholder in-place.
        characters = Canon.wantedTop25.map {
            Canon.placeholderCharacter(name: $0)
        }
        collectionView.reloadData()
        collectionView.collectionViewLayout.invalidateLayout()

        loadingIndicator.startAnimating()
        let group = DispatchGroup()

        for (index, canonicalName) in Canon.wantedTop25.enumerated() {
            group.enter()
            APIService.shared.searchCharacters(name: canonicalName) { [weak self] result in
                defer { group.leave() }
                guard case .success(let matches) = result, !matches.isEmpty else { return }
                guard let real = self?.bestMatch(for: canonicalName, in: matches) else { return }
                DispatchQueue.main.async {
                    guard let self = self, index < self.characters.count else { return }
                    self.characters[index] = real
                    let path = IndexPath(item: index, section: 0)
                    if self.collectionView.indexPathsForVisibleItems.contains(path) {
                        self.collectionView.reloadItems(at: [path])
                    }
                }
            }
        }

        group.notify(queue: .main) { [weak self] in
            self?.loadingIndicator.stopAnimating()
        }
    }

    // Pick the best match for a canonical name. The API's name filter is a
    // substring search, so "Sanji" returns multiple — prefer exact name.
    private func bestMatch(for canonicalName: String, in matches: [Character]) -> Character? {
        let target = canonicalName.lowercased()
        if let exact = matches.first(where: { $0.name.lowercased() == target }) { return exact }
        if let contains = matches.first(where: { $0.name.lowercased().contains(target) }) { return contains }
        return matches.first
    }
}

extension LeaderboardViewController: UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int {
        characters.count
    }
    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: WantedPosterCell.reuseID,
                                           for: indexPath) as! WantedPosterCell
        cell.configure(rank: indexPath.item + 1, character: characters[indexPath.item])
        return cell
    }
}

extension LeaderboardViewController: UICollectionViewDelegate {
    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        let detail = CharacterDetailViewController(character: characters[indexPath.item])
        navigationController?.pushViewController(detail, animated: true)
    }
}
