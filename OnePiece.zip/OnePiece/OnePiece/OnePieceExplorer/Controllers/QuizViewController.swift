import UIKit

// QuizViewController
// One Piece trivia quiz. Generates questions on the fly from API data:
//   - "Who has this bounty?"
//   - "Which crew is this character in?"
//   - "Who ate the X Devil Fruit?"
//
// Whole layout is wrapped in a UIScrollView so content never gets clipped by
// the tab bar, even with 4 answer cards stacked vertically on small screens.

final class QuizViewController: UIViewController {

    //  Data
    private var pool: [Character] = []     // characters with enough data to form questions
    private var fruits: [DevilFruit] = []
    private var currentQuestion: QuizQuestion?

    private var score = 0
    private var streak = 0
    private var questionNumber = 0
    private var hasAnswered = false

    // UI — scroll wrapper
    private let scrollView    = UIScrollView()
    private let contentView   = UIView()

    // Header card
    private let headerCard      = UIView()
    private let scoreLabel      = UILabel()
    private let streakLabel     = UILabel()
    private let questionCounter = UILabel()

    // Question card
    private let questionCard    = UIView()
    private let promptLabel     = UILabel()
    private let subjectImageView = UIImageView()
    private let subjectInitials  = UILabel()
    private let subjectName     = UILabel()

    // Answer stack
    private let answerStack     = UIStackView()
    private var answerButtons: [UIButton] = []

    // Next button
    private let nextButton      = UIButton(type: .system)
    private let resultLabel     = UILabel()

    private let loadingIndicator: UIActivityIndicatorView = {
        let ai = UIActivityIndicatorView(style: .large)
        ai.color = Theme.gold
        ai.hidesWhenStopped = true
        ai.translatesAutoresizingMaskIntoConstraints = false
        return ai
    }()

    // Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Quiz"
        navigationController?.navigationBar.prefersLargeTitles = true
        Theme.applyNavBar(to: navigationController)
        view.backgroundColor = Theme.pageBG

        setupScrollWrapper()
        setupHeaderCard()
        setupQuestionCard()
        setupAnswerStack()
        setupResultAndNext()
        view.addSubview(loadingIndicator)
        NSLayoutConstraint.activate([
            loadingIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        ])
        fetchPool()
    }

    // Scroll wrapper
    // The key fix: everything goes inside a scroll view so the Next button
    // never gets stuck under the tab bar on iPhone SE / smaller screens.
    private func setupScrollWrapper() {
        scrollView.alwaysBounceVertical = true
        scrollView.showsVerticalScrollIndicator = false
        // contentInset so the last item clears the tab bar comfortably
        scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 40, right: 0)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
        ])
    }

    private func setupHeaderCard() {
        headerCard.backgroundColor    = Theme.cardBG
        headerCard.layer.cornerRadius = 14
        headerCard.layer.borderWidth  = 0.5
        headerCard.layer.borderColor  = UIColor.white.withAlphaComponent(0.08).cgColor
        headerCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(headerCard)

        scoreLabel.font          = .monospacedSystemFont(ofSize: 22, weight: .heavy)
        scoreLabel.textColor     = Theme.gold
        scoreLabel.textAlignment = .center

        let scoreTag = UILabel()
        scoreTag.text          = "SCORE"
        scoreTag.font          = .systemFont(ofSize: 9, weight: .heavy)
        scoreTag.textColor     = UIColor.white.withAlphaComponent(0.45)
        scoreTag.textAlignment = .center

        streakLabel.font          = .monospacedSystemFont(ofSize: 22, weight: .heavy)
        streakLabel.textColor     = UIColor(red:0.95,green:0.55,blue:0.20,alpha:1)
        streakLabel.textAlignment = .center

        let streakTag = UILabel()
        streakTag.text          = "🔥 STREAK"
        streakTag.font          = .systemFont(ofSize: 9, weight: .heavy)
        streakTag.textColor     = UIColor.white.withAlphaComponent(0.45)
        streakTag.textAlignment = .center

        questionCounter.font          = .monospacedSystemFont(ofSize: 22, weight: .heavy)
        questionCounter.textColor     = .white
        questionCounter.textAlignment = .center

        let qTag = UILabel()
        qTag.text          = "QUESTION"
        qTag.font          = .systemFont(ofSize: 9, weight: .heavy)
        qTag.textColor     = UIColor.white.withAlphaComponent(0.45)
        qTag.textAlignment = .center

        let scoreCol  = UIStackView(arrangedSubviews: [scoreLabel, scoreTag]);  scoreCol.axis = .vertical;  scoreCol.spacing = 1
        let streakCol = UIStackView(arrangedSubviews: [streakLabel, streakTag]); streakCol.axis = .vertical; streakCol.spacing = 1
        let qCol      = UIStackView(arrangedSubviews: [questionCounter, qTag]);  qCol.axis = .vertical;     qCol.spacing = 1

        let row       = UIStackView(arrangedSubviews: [scoreCol, streakCol, qCol])
        row.axis      = .horizontal
        row.distribution = .fillEqually
        row.translatesAutoresizingMaskIntoConstraints = false
        headerCard.addSubview(row)

        NSLayoutConstraint.activate([
            headerCard.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            headerCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            headerCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            headerCard.heightAnchor.constraint(equalToConstant: 78),

            row.topAnchor.constraint(equalTo: headerCard.topAnchor, constant: 12),
            row.leadingAnchor.constraint(equalTo: headerCard.leadingAnchor, constant: 12),
            row.trailingAnchor.constraint(equalTo: headerCard.trailingAnchor, constant: -12),
            row.bottomAnchor.constraint(equalTo: headerCard.bottomAnchor, constant: -12),
        ])

        scoreLabel.text       = "0"
        streakLabel.text      = "0"
        questionCounter.text  = "1"
    }

    private func setupQuestionCard() {
        questionCard.backgroundColor    = Theme.cardBG
        questionCard.layer.cornerRadius = 14
        questionCard.layer.borderWidth  = 0.5
        questionCard.layer.borderColor  = UIColor.white.withAlphaComponent(0.08).cgColor
        questionCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(questionCard)

        promptLabel.font          = .systemFont(ofSize: 16, weight: .semibold)
        promptLabel.textColor     = .white
        promptLabel.textAlignment = .center
        promptLabel.numberOfLines = 0
        promptLabel.translatesAutoresizingMaskIntoConstraints = false
        questionCard.addSubview(promptLabel)

        subjectImageView.contentMode     = .scaleAspectFit
        subjectImageView.clipsToBounds   = true
        subjectImageView.layer.cornerRadius = 12
        subjectImageView.backgroundColor = UIColor.white.withAlphaComponent(0.04)
        subjectImageView.translatesAutoresizingMaskIntoConstraints = false
        questionCard.addSubview(subjectImageView)

        subjectInitials.font          = .systemFont(ofSize: 44, weight: .heavy)
        subjectInitials.textColor     = UIColor.white.withAlphaComponent(0.25)
        subjectInitials.textAlignment = .center
        subjectInitials.translatesAutoresizingMaskIntoConstraints = false
        questionCard.addSubview(subjectInitials)

        subjectName.font          = .systemFont(ofSize: 13, weight: .medium)
        subjectName.textColor     = UIColor.white.withAlphaComponent(0.5)
        subjectName.textAlignment = .center
        subjectName.translatesAutoresizingMaskIntoConstraints = false
        questionCard.addSubview(subjectName)

        NSLayoutConstraint.activate([
            questionCard.topAnchor.constraint(equalTo: headerCard.bottomAnchor, constant: 14),
            questionCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            questionCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            promptLabel.topAnchor.constraint(equalTo: questionCard.topAnchor, constant: 16),
            promptLabel.leadingAnchor.constraint(equalTo: questionCard.leadingAnchor, constant: 16),
            promptLabel.trailingAnchor.constraint(equalTo: questionCard.trailingAnchor, constant: -16),

            subjectImageView.topAnchor.constraint(equalTo: promptLabel.bottomAnchor, constant: 14),
            subjectImageView.centerXAnchor.constraint(equalTo: questionCard.centerXAnchor),
            subjectImageView.widthAnchor.constraint(equalToConstant: 140),
            subjectImageView.heightAnchor.constraint(equalToConstant: 140),

            subjectInitials.centerXAnchor.constraint(equalTo: subjectImageView.centerXAnchor),
            subjectInitials.centerYAnchor.constraint(equalTo: subjectImageView.centerYAnchor),

            subjectName.topAnchor.constraint(equalTo: subjectImageView.bottomAnchor, constant: 8),
            subjectName.leadingAnchor.constraint(equalTo: questionCard.leadingAnchor, constant: 12),
            subjectName.trailingAnchor.constraint(equalTo: questionCard.trailingAnchor, constant: -12),
            subjectName.bottomAnchor.constraint(equalTo: questionCard.bottomAnchor, constant: -16),
        ])
    }

    private func setupAnswerStack() {
        answerStack.axis        = .vertical
        answerStack.spacing     = 10
        answerStack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(answerStack)

        for i in 0..<4 {
            let b = UIButton(type: .system)
            b.tag = i
            b.titleLabel?.font           = .systemFont(ofSize: 15, weight: .semibold)
            b.titleLabel?.numberOfLines  = 0
            b.titleLabel?.textAlignment  = .center
            b.layer.cornerRadius         = 12
            b.layer.borderWidth          = 1.5
            b.heightAnchor.constraint(greaterThanOrEqualToConstant: 56).isActive = true
            b.contentEdgeInsets          = UIEdgeInsets(top: 10, left: 14, bottom: 10, right: 14)
            b.addTarget(self, action: #selector(answerTapped(_:)), for: .touchUpInside)
            answerButtons.append(b)
            answerStack.addArrangedSubview(b)
        }

        NSLayoutConstraint.activate([
            answerStack.topAnchor.constraint(equalTo: questionCard.bottomAnchor, constant: 14),
            answerStack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            answerStack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
        ])
    }

    private func setupResultAndNext() {
        resultLabel.font          = .systemFont(ofSize: 14, weight: .semibold)
        resultLabel.textAlignment = .center
        resultLabel.numberOfLines = 0
        resultLabel.alpha         = 0
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(resultLabel)

        nextButton.setTitle("Next Question →", for: .normal)
        nextButton.titleLabel?.font     = .systemFont(ofSize: 16, weight: .heavy)
        nextButton.setTitleColor(UIColor(red:0.1,green:0.1,blue:0.1,alpha:1), for: .normal)
        nextButton.backgroundColor      = Theme.gold
        nextButton.layer.cornerRadius   = 14
        nextButton.layer.masksToBounds  = true
        nextButton.isHidden             = true
        nextButton.addTarget(self, action: #selector(nextTapped), for: .touchUpInside)
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(nextButton)

        NSLayoutConstraint.activate([
            resultLabel.topAnchor.constraint(equalTo: answerStack.bottomAnchor, constant: 14),
            resultLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            resultLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            nextButton.topAnchor.constraint(equalTo: resultLabel.bottomAnchor, constant: 10),
            nextButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            nextButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            nextButton.heightAnchor.constraint(equalToConstant: 52),
            // Anchor to content bottom so scrollView's contentSize includes everything
            nextButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16),
        ])
    }

    // Pool fetch
    private func fetchPool() {
        loadingIndicator.startAnimating()
        let group = DispatchGroup()
        group.enter()
        APIService.shared.fetchManyPages(4) { [weak self] result in
            if case .success(let chars) = result {
                self?.pool = chars.filter { $0.bountyValue > 0 && $0.affiliations?.isEmpty == false }
            }
            group.leave()
        }
        group.enter()
        APIService.shared.fetchDevilFruits(page: 1) { [weak self] result in
            if case .success(let f) = result { self?.fruits = f }
            group.leave()
        }
        group.notify(queue: .main) { [weak self] in
            self?.loadingIndicator.stopAnimating()
            self?.nextQuestion()
        }
    }

    // Question generation
    private func nextQuestion() {
        guard pool.count >= 4 else { return }
        hasAnswered = false
        resultLabel.alpha = 0
        nextButton.isHidden = true

        questionNumber += 1
        questionCounter.text = "\(questionNumber)"

        // Pick a question type
        let types: [QuestionType] = [.bounty, .crew, .fruit]
        let availableFruit = fruits.filter { !($0.currentOwner ?? "").isEmpty }
        let type: QuestionType = availableFruit.count >= 4
            ? types.randomElement() ?? .bounty
            : ([.bounty, .crew]).randomElement() ?? .bounty

        switch type {
        case .bounty: currentQuestion = makeBountyQuestion()
        case .crew:   currentQuestion = makeCrewQuestion()
        case .fruit:  currentQuestion = makeFruitQuestion()
        }

        guard let q = currentQuestion else { return }
        promptLabel.text  = q.prompt
        subjectName.text  = q.subjectName ?? ""
        loadSubjectImage(q.subjectImageURL, fallback: q.subjectName ?? "?")

        for (i, btn) in answerButtons.enumerated() {
            btn.setTitle(q.options[i], for: .normal)
            btn.isEnabled = true
            btn.setTitleColor(.white, for: .normal)
            btn.backgroundColor   = UIColor.white.withAlphaComponent(0.06)
            btn.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        }

        // Scroll to top so the new question is visible
        scrollView.setContentOffset(.zero, animated: true)
    }

    private enum QuestionType { case bounty, crew, fruit }

    private func makeBountyQuestion() -> QuizQuestion? {
        guard let subject = pool.randomElement() else { return nil }
        var others = pool.filter { $0.id != subject.id }.shuffled().prefix(3).map { $0 }
        others.append(subject)
        others.shuffle()
        let options = others.map { $0.bountyFormatted }
        let correctIndex = others.firstIndex { $0.id == subject.id } ?? 0
        return QuizQuestion(
            prompt: "What is the bounty of this character?",
            subjectName: subject.name,
            subjectImageURL: subject.bestImageURL,
            options: options, correctIndex: correctIndex,
            explanation: "\(subject.name)'s bounty is \(subject.bountyFormatted)."
        )
    }

    private func makeCrewQuestion() -> QuizQuestion? {
        // Find subjects with a recognizable crew
        let withCrew = pool.filter { CrewsCatalog.crew(for: $0) != nil }
        guard let subject = withCrew.randomElement(),
              let correctCrew = CrewsCatalog.crew(for: subject) else { return nil }

        // Pick 3 wrong crews
        var others = CrewsCatalog.all.filter { $0.name != correctCrew.name }.shuffled().prefix(3).map { $0 }
        others.append(correctCrew)
        others.shuffle()
        let options = others.map { $0.name }
        let correctIndex = others.firstIndex { $0.name == correctCrew.name } ?? 0
        return QuizQuestion(
            prompt: "Which crew does this character belong to?",
            subjectName: subject.name,
            subjectImageURL: subject.bestImageURL,
            options: options, correctIndex: correctIndex,
            explanation: "\(subject.name) is a member of the \(correctCrew.name)."
        )
    }

    private func makeFruitQuestion() -> QuizQuestion? {
        // Pick a fruit with a known owner
        let owned = fruits.filter { !($0.currentOwner ?? "").isEmpty }
        guard let subject = owned.randomElement(), let owner = subject.currentOwner else { return nil }

        // Wrong options: other characters' names
        var wrongOwners = pool.map { $0.name }.filter { $0 != owner }.shuffled().prefix(3).map { $0 }
        wrongOwners.append(owner)
        wrongOwners.shuffle()
        let correctIndex = wrongOwners.firstIndex(of: owner) ?? 0
        return QuizQuestion(
            prompt: "Who ate the \(subject.name)?",
            subjectName: subject.name,
            subjectImageURL: subject.avatarSrc,
            options: wrongOwners, correctIndex: correctIndex,
            explanation: "\(owner) is the current user of the \(subject.name)."
        )
    }

    // Subject image
    private func loadSubjectImage(_ urlString: String?, fallback: String) {
        subjectImageView.image = nil
        subjectInitials.text   = String(fallback.prefix(1))
        subjectInitials.isHidden = false
        guard let s = urlString, let url = URL(string: s) else { return }
        if let cached = ImageCache.shared.image(for: url) {
            subjectImageView.image = cached
            subjectInitials.isHidden = true
            return
        }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let img = UIImage(data: data) else { return }
            ImageCache.shared.store(img, for: url)
            DispatchQueue.main.async {
                self?.subjectImageView.image = img
                self?.subjectInitials.isHidden = true
            }
        }.resume()
    }

    // Answer handling
    @objc private func answerTapped(_ sender: UIButton) {
        guard !hasAnswered, let q = currentQuestion else { return }
        hasAnswered = true
        let chosen = sender.tag
        let isCorrect = chosen == q.correctIndex

        // Color all buttons
        for (i, btn) in answerButtons.enumerated() {
            btn.isEnabled = false
            if i == q.correctIndex {
                btn.backgroundColor   = UIColor(red:0.11, green:0.55, blue:0.40, alpha:0.35)
                btn.layer.borderColor = UIColor(red:0.30, green:0.78, blue:0.55, alpha:1).cgColor
                btn.setTitleColor(.white, for: .normal)
            } else if i == chosen {
                btn.backgroundColor   = UIColor(red:0.64, green:0.18, blue:0.18, alpha:0.35)
                btn.layer.borderColor = UIColor(red:0.89, green:0.30, blue:0.29, alpha:1).cgColor
            } else {
                btn.alpha = 0.4
            }
        }

        if isCorrect {
            score  += 10 + (streak * 2)
            streak += 1
            resultLabel.text      = "✓ Correct! +\(10 + (streak - 1) * 2) points"
            resultLabel.textColor = UIColor(red:0.30, green:0.78, blue:0.55, alpha:1)
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        } else {
            streak = 0
            resultLabel.text      = "✗ \(q.explanation)"
            resultLabel.textColor = UIColor(red:0.89, green:0.50, blue:0.45, alpha:1)
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        }

        scoreLabel.text  = "\(score)"
        streakLabel.text = "\(streak)"

        UIView.animate(withDuration: 0.25) { self.resultLabel.alpha = 1 }
        nextButton.isHidden = false

        // Scroll the next button into view so user always sees it
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            self.scrollView.scrollRectToVisible(self.nextButton.frame, animated: true)
        }
    }

    @objc private func nextTapped() {
        // Reset button alpha
        answerButtons.forEach { $0.alpha = 1 }
        nextQuestion()
    }
}

// QuizQuestion model

struct QuizQuestion {
    let prompt: String
    let subjectName: String?
    let subjectImageURL: String?
    let options: [String]
    let correctIndex: Int
    let explanation: String
}
