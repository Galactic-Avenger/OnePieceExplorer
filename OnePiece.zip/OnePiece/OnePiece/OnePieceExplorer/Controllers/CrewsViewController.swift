import UIKit

// CrewsViewController
// Grid of crew cards. Member counts come straight from the canonical roster in
// CrewsCatalog — no API loading needed. Tapping a crew opens CrewDetailViewController
// which then fetches each canonical member from the API.

final class CrewsViewController: UIViewController {

    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 12
        layout.minimumLineSpacing      = 14
        layout.sectionInset            = UIEdgeInsets(top: 12, left: 16, bottom: 24, right: 16)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.backgroundColor = Theme.pageBG
        cv.alwaysBounceVertical = true
        cv.register(CrewCardCell.self, forCellWithReuseIdentifier: CrewCardCell.reuseID)
        cv.dataSource = self
        cv.delegate   = self
        cv.translatesAutoresizingMaskIntoConstraints = false
        return cv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Crews"
        navigationController?.navigationBar.prefersLargeTitles = true
        Theme.applyNavBar(to: navigationController)
        view.backgroundColor = Theme.pageBG

        view.addSubview(collectionView)
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }
}

extension CrewsViewController: UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int {
        CrewsCatalog.all.count
    }
    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: CrewCardCell.reuseID,
                                           for: indexPath) as! CrewCardCell
        let crew = CrewsCatalog.all[indexPath.item]
        cell.configure(crew: crew, memberCount: crew.coreMembers.count)
        return cell
    }
}

extension CrewsViewController: UICollectionViewDelegate {
    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        let crew = CrewsCatalog.all[indexPath.item]
        let detail = CrewDetailViewController(crew: crew)
        navigationController?.pushViewController(detail, animated: true)
    }
}

extension CrewsViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ cv: UICollectionView, layout _: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding: CGFloat = 16 * 2 + 12
        let width            = (cv.bounds.width - padding) / 2
        return CGSize(width: width, height: width * 0.95)
    }
}

// CrewCardCell

final class CrewCardCell: UICollectionViewCell {
    static let reuseID = "CrewCardCell"

    private let gradientLayer = CAGradientLayer()
    private let emblemLabel   = UILabel()
    private let nameLabel     = UILabel()
    private let countLabel    = UILabel()
    private let taglineLabel  = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = contentView.bounds
        contentView.layer.cornerRadius = 14
        contentView.clipsToBounds = true
    }

    private func setup() {
        contentView.layer.cornerRadius = 14
        contentView.layer.borderWidth  = 0.5
        contentView.layer.borderColor  = UIColor.white.withAlphaComponent(0.1).cgColor
        contentView.layer.insertSublayer(gradientLayer, at: 0)

        emblemLabel.font          = .systemFont(ofSize: 40)
        emblemLabel.textAlignment = .center

        nameLabel.font            = .systemFont(ofSize: 14, weight: .heavy)
        nameLabel.textColor       = .white
        nameLabel.textAlignment   = .center
        nameLabel.numberOfLines   = 2
        nameLabel.adjustsFontSizeToFitWidth = true
        nameLabel.minimumScaleFactor        = 0.7

        countLabel.font           = .monospacedSystemFont(ofSize: 11, weight: .bold)
        countLabel.textAlignment  = .center

        taglineLabel.font         = .systemFont(ofSize: 10)
        taglineLabel.textColor    = UIColor.white.withAlphaComponent(0.55)
        taglineLabel.textAlignment = .center
        taglineLabel.numberOfLines = 2

        let stack = UIStackView(arrangedSubviews: [emblemLabel, nameLabel, countLabel, taglineLabel])
        stack.axis    = .vertical
        stack.spacing = 4
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            stack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
        ])
    }

    func configure(crew: CrewInfo, memberCount: Int) {
        emblemLabel.text  = crew.emblem
        nameLabel.text    = crew.name
        taglineLabel.text = crew.tagline
        let accent = Theme.accentColor(for: crew.theme)
        countLabel.text       = "\(memberCount) MEMBERS"
        countLabel.textColor  = accent
        Theme.applyGradient(to: gradientLayer, theme: crew.theme)
        contentView.layer.borderColor = accent.withAlphaComponent(0.4).cgColor
    }

    override var isHighlighted: Bool {
        didSet {
            UIView.animate(withDuration: 0.12) {
                self.transform = self.isHighlighted
                    ? CGAffineTransform(scaleX: 0.95, y: 0.95) : .identity
            }
        }
    }
}
