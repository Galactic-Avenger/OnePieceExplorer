import UIKit

// CharacterDetailViewController  (Screen 2)
// Rebuilt from scratch — proper rectangular hero image (no oval clipping),
// badges as overlays on the image (not floating in empty space),
// name + crew in a banner below the image, info card with new GraphQL fields,
// bio card from the API description, and a favorite button at the bottom.
// Everything wrapped in a scroll view so it actually scrolls to the end.

final class CharacterDetailViewController: UIViewController {

    private let character: Character

    init(character: Character) {
        self.character = character
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    // Hero size
    static let heroHeight: CGFloat = 320

    //  UI
    private let scrollView      = UIScrollView()
    private let contentView     = UIView()

    private let heroContainer   = UIView()
    private let heroImageView   = UIImageView()
    private let initialsView    = UIView()
    private let initialsLabel   = UILabel()
    private let dfTypeBadge     = PaddedLabel()
    private let originBadge     = PaddedLabel()
    private let heroFadeLayer   = CAGradientLayer()

    private let nameBanner      = UIView()
    private let nameLabel       = UILabel()
    private let crewLabel       = UILabel()
    private let rarityChip      = PaddedLabel()

    private let infoCard        = UIView()
    private let bountyValueLabel = BountyLabel()
    private let fruitLabel      = UILabel()
    private let ageLabel        = UILabel()
    private let birthdayLabel   = UILabel()
    private let bloodTypeLabel  = UILabel()
    private let originLabel     = UILabel()
    private let debutLabel      = UILabel()

    private let bioCard         = UIView()
    private let bioLabel        = UILabel()

    private let favoriteButton  = UIButton(type: .system)

    // Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavBar()
        setupScrollContainer()
        setupHero()
        setupNameBanner()
        setupInfoCard()
        setupBioCard()
        setupFavoriteButton()
        populate()
        updateFavoriteButton()
        loadImage()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Make sure the dark fade always covers the bottom of the hero image
        heroFadeLayer.frame = heroContainer.bounds
        initialsView.layer.cornerRadius = initialsView.bounds.width / 2
    }

    // Nav bar
    private func setupNavBar() {
        title = "Character"
        Theme.applyNavBar(to: navigationController)
        let shareItem = UIBarButtonItem(image: UIImage(systemName: "square.and.arrow.up"),
                                        style: .plain, target: self,
                                        action: #selector(shareTapped))
        shareItem.tintColor = Theme.gold
        navigationItem.rightBarButtonItem = shareItem
    }

    // Scroll container
    private func setupScrollContainer() {
        view.backgroundColor = Theme.pageBG

        scrollView.alwaysBounceVertical          = true
        scrollView.showsVerticalScrollIndicator  = true
        scrollView.contentInsetAdjustmentBehavior = .never
        scrollView.translatesAutoresizingMaskIntoConstraints  = false
        contentView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
        ])
    }

    //  Hero
    // A real rectangle, not an oval. Image fills via scaleAspectFill so faces aren't cropped weird.
    // Badges are overlaid in the corners of the image, not floating in empty space.
    private func setupHero() {
        heroContainer.clipsToBounds = true
        heroContainer.backgroundColor = Theme.cardBG
        heroContainer.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(heroContainer)

        heroImageView.contentMode     = .scaleAspectFill
        heroImageView.clipsToBounds   = true
        heroImageView.backgroundColor = Theme.cardBG
        heroImageView.translatesAutoresizingMaskIntoConstraints = false
        heroContainer.addSubview(heroImageView)

        // Initials fallback if image fails — sits behind the image
        let accent = Theme.accentColor(for: character.crewTheme)
        initialsView.backgroundColor    = accent.withAlphaComponent(0.18)
        initialsView.layer.borderWidth  = 3
        initialsView.layer.borderColor  = accent.cgColor
        initialsView.translatesAutoresizingMaskIntoConstraints = false
        heroContainer.addSubview(initialsView)

        initialsLabel.font          = .systemFont(ofSize: 40, weight: .heavy)
        initialsLabel.textColor     = accent
        initialsLabel.textAlignment = .center
        initialsLabel.translatesAutoresizingMaskIntoConstraints = false
        initialsView.addSubview(initialsLabel)

        // Bottom dark fade for badge/text legibility
        heroFadeLayer.colors    = [UIColor.clear.cgColor,
                                   UIColor.black.withAlphaComponent(0.55).cgColor,
                                   UIColor.black.withAlphaComponent(0.85).cgColor]
        heroFadeLayer.locations = [0.4, 0.75, 1.0]
        heroContainer.layer.addSublayer(heroFadeLayer)

        // Top-left: devil fruit type badge
        dfTypeBadge.font           = .systemFont(ofSize: 11, weight: .heavy)
        dfTypeBadge.textColor      = .white
        dfTypeBadge.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        dfTypeBadge.layer.cornerRadius  = 8
        dfTypeBadge.layer.masksToBounds = true
        dfTypeBadge.padding             = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
        dfTypeBadge.translatesAutoresizingMaskIntoConstraints = false
        heroContainer.addSubview(dfTypeBadge)

        // Top-right: origin badge
        originBadge.font            = .systemFont(ofSize: 11, weight: .semibold)
        originBadge.textColor       = .white
        originBadge.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        originBadge.layer.cornerRadius  = 8
        originBadge.layer.masksToBounds = true
        originBadge.padding             = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
        originBadge.textAlignment       = .right
        originBadge.translatesAutoresizingMaskIntoConstraints = false
        heroContainer.addSubview(originBadge)

        NSLayoutConstraint.activate([
            heroContainer.topAnchor.constraint(equalTo: contentView.topAnchor),
            heroContainer.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            heroContainer.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            heroContainer.heightAnchor.constraint(equalToConstant: Self.heroHeight),

            heroImageView.topAnchor.constraint(equalTo: heroContainer.topAnchor),
            heroImageView.leadingAnchor.constraint(equalTo: heroContainer.leadingAnchor),
            heroImageView.trailingAnchor.constraint(equalTo: heroContainer.trailingAnchor),
            heroImageView.bottomAnchor.constraint(equalTo: heroContainer.bottomAnchor),

            initialsView.centerXAnchor.constraint(equalTo: heroContainer.centerXAnchor),
            initialsView.centerYAnchor.constraint(equalTo: heroContainer.centerYAnchor),
            initialsView.widthAnchor.constraint(equalToConstant: 110),
            initialsView.heightAnchor.constraint(equalToConstant: 110),

            initialsLabel.centerXAnchor.constraint(equalTo: initialsView.centerXAnchor),
            initialsLabel.centerYAnchor.constraint(equalTo: initialsView.centerYAnchor),

            dfTypeBadge.topAnchor.constraint(equalTo: heroContainer.safeAreaLayoutGuide.topAnchor, constant: 12),
            dfTypeBadge.leadingAnchor.constraint(equalTo: heroContainer.leadingAnchor, constant: 14),

            originBadge.topAnchor.constraint(equalTo: heroContainer.safeAreaLayoutGuide.topAnchor, constant: 12),
            originBadge.trailingAnchor.constraint(equalTo: heroContainer.trailingAnchor, constant: -14),
            originBadge.leadingAnchor.constraint(greaterThanOrEqualTo: dfTypeBadge.trailingAnchor, constant: 8),
        ])
    }

    // Name banner below the hero
    private func setupNameBanner() {
        nameBanner.backgroundColor = Theme.cardBG
        nameBanner.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(nameBanner)

        nameLabel.font          = .systemFont(ofSize: 26, weight: .heavy)
        nameLabel.textColor     = .white
        nameLabel.adjustsFontSizeToFitWidth = true
        nameLabel.minimumScaleFactor        = 0.6
        nameLabel.translatesAutoresizingMaskIntoConstraints = false

        crewLabel.font          = .systemFont(ofSize: 13, weight: .semibold)
        crewLabel.textColor     = Theme.accentColor(for: character.crewTheme)
        crewLabel.translatesAutoresizingMaskIntoConstraints = false

        rarityChip.font           = .systemFont(ofSize: 11, weight: .heavy)
        rarityChip.textColor      = .black
        rarityChip.backgroundColor = Theme.rarityColor(for: character.rarity)
        rarityChip.layer.cornerRadius  = 10
        rarityChip.layer.masksToBounds = true
        rarityChip.padding             = UIEdgeInsets(top: 3, left: 8, bottom: 3, right: 8)
        rarityChip.translatesAutoresizingMaskIntoConstraints = false

        [nameLabel, crewLabel, rarityChip].forEach { nameBanner.addSubview($0) }

        NSLayoutConstraint.activate([
            nameBanner.topAnchor.constraint(equalTo: heroContainer.bottomAnchor),
            nameBanner.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            nameBanner.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),

            nameLabel.topAnchor.constraint(equalTo: nameBanner.topAnchor, constant: 14),
            nameLabel.leadingAnchor.constraint(equalTo: nameBanner.leadingAnchor, constant: 18),
            nameLabel.trailingAnchor.constraint(equalTo: rarityChip.leadingAnchor, constant: -10),

            rarityChip.centerYAnchor.constraint(equalTo: nameLabel.centerYAnchor),
            rarityChip.trailingAnchor.constraint(equalTo: nameBanner.trailingAnchor, constant: -18),

            crewLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            crewLabel.leadingAnchor.constraint(equalTo: nameBanner.leadingAnchor, constant: 18),
            crewLabel.trailingAnchor.constraint(equalTo: nameBanner.trailingAnchor, constant: -18),
            crewLabel.bottomAnchor.constraint(equalTo: nameBanner.bottomAnchor, constant: -14),
        ])
    }

    // Info card with the new GraphQL fields
    private func setupInfoCard() {
        infoCard.backgroundColor    = Theme.cardBG
        infoCard.layer.cornerRadius = 14
        infoCard.layer.borderWidth  = 0.5
        infoCard.layer.borderColor  = UIColor.white.withAlphaComponent(0.08).cgColor
        infoCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(infoCard)

        bountyValueLabel.style = .full

        let rows: [(String, UILabel)] = [
            ("Bounty",      bountyValueLabel),
            ("Devil Fruit", fruitLabel),
            ("Age",         ageLabel),
            ("Birthday",    birthdayLabel),
            ("Blood Type",  bloodTypeLabel),
            ("Origin",      originLabel),
            ("Debut",       debutLabel),
        ]

        let stack = UIStackView()
        stack.axis    = .vertical
        stack.spacing = 0
        stack.translatesAutoresizingMaskIntoConstraints = false
        infoCard.addSubview(stack)

        rows.enumerated().forEach { i, pair in
            stack.addArrangedSubview(
                makeRow(title: pair.0, valueLabel: pair.1, isLast: i == rows.count - 1))
        }

        NSLayoutConstraint.activate([
            infoCard.topAnchor.constraint(equalTo: nameBanner.bottomAnchor, constant: 14),
            infoCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            infoCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            stack.topAnchor.constraint(equalTo: infoCard.topAnchor, constant: 4),
            stack.leadingAnchor.constraint(equalTo: infoCard.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: infoCard.trailingAnchor),
            stack.bottomAnchor.constraint(equalTo: infoCard.bottomAnchor, constant: -4),
        ])
    }

    // Biography card
    private func setupBioCard() {
        bioCard.backgroundColor    = Theme.cardBG
        bioCard.layer.cornerRadius = 14
        bioCard.layer.borderWidth  = 0.5
        bioCard.layer.borderColor  = UIColor.white.withAlphaComponent(0.08).cgColor
        bioCard.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(bioCard)

        let bioTitle        = UILabel()
        bioTitle.text       = "BIOGRAPHY"
        bioTitle.font       = .systemFont(ofSize: 12, weight: .heavy)
        bioTitle.textColor  = Theme.gold

        bioLabel.font          = .systemFont(ofSize: 14)
        bioLabel.textColor     = UIColor.white.withAlphaComponent(0.78)
        bioLabel.numberOfLines = 0
        bioLabel.lineBreakMode = .byWordWrapping

        [bioTitle, bioLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            bioCard.addSubview($0)
        }

        NSLayoutConstraint.activate([
            bioCard.topAnchor.constraint(equalTo: infoCard.bottomAnchor, constant: 14),
            bioCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            bioCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            bioTitle.topAnchor.constraint(equalTo: bioCard.topAnchor, constant: 14),
            bioTitle.leadingAnchor.constraint(equalTo: bioCard.leadingAnchor, constant: 16),
            bioTitle.trailingAnchor.constraint(equalTo: bioCard.trailingAnchor, constant: -16),

            bioLabel.topAnchor.constraint(equalTo: bioTitle.bottomAnchor, constant: 8),
            bioLabel.leadingAnchor.constraint(equalTo: bioCard.leadingAnchor, constant: 16),
            bioLabel.trailingAnchor.constraint(equalTo: bioCard.trailingAnchor, constant: -16),
            bioLabel.bottomAnchor.constraint(equalTo: bioCard.bottomAnchor, constant: -16),
        ])
    }

    // Favorite button — anchored to the content view bottom
    private func setupFavoriteButton() {
        favoriteButton.titleLabel?.font    = .systemFont(ofSize: 16, weight: .heavy)
        favoriteButton.layer.cornerRadius  = 14
        favoriteButton.layer.masksToBounds = true
        favoriteButton.addTarget(self, action: #selector(favoriteTapped), for: .touchUpInside)
        favoriteButton.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(favoriteButton)

        NSLayoutConstraint.activate([
            favoriteButton.topAnchor.constraint(equalTo: bioCard.bottomAnchor, constant: 18),
            favoriteButton.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            favoriteButton.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            favoriteButton.heightAnchor.constraint(equalToConstant: 54),
            favoriteButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -40),
        ])
    }

    // Build a label row
    private func makeRow(title: String, valueLabel: UILabel, isLast: Bool) -> UIView {
        let container  = UIView()
        let titleLabel = UILabel()
        titleLabel.text      = title
        titleLabel.font      = .systemFont(ofSize: 14)
        titleLabel.textColor = UIColor.white.withAlphaComponent(0.55)

        valueLabel.font                      = .systemFont(ofSize: 14, weight: .semibold)
        valueLabel.textColor                 = .white
        valueLabel.textAlignment             = .right
        valueLabel.numberOfLines             = 2
        valueLabel.adjustsFontSizeToFitWidth = true
        valueLabel.minimumScaleFactor        = 0.65

        let sep             = UIView()
        sep.backgroundColor = UIColor.white.withAlphaComponent(0.07)
        sep.isHidden        = isLast

        [titleLabel, valueLabel, sep].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview($0)
        }
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: container.topAnchor, constant: 14),
            titleLabel.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            titleLabel.bottomAnchor.constraint(equalTo: container.bottomAnchor, constant: -14),
            titleLabel.widthAnchor.constraint(equalToConstant: 100),

            valueLabel.centerYAnchor.constraint(equalTo: titleLabel.centerYAnchor),
            valueLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            valueLabel.leadingAnchor.constraint(equalTo: titleLabel.trailingAnchor, constant: 8),

            sep.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            sep.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            sep.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            sep.heightAnchor.constraint(equalToConstant: 0.5),
        ])
        return container
    }

    // Populate
    private func populate() {
        nameLabel.text   = character.name
        crewLabel.text   = character.crewDisplayName.uppercased()
        rarityChip.text  = character.rarity.rawValue

        // Use the Character variant so the canonical bounty override (Canon) applies
        bountyValueLabel.setBounty(character)

        // Devil Fruit — show "None" gracefully if blank
        let fruit = character.devilFruitDisplay
        fruitLabel.text      = fruit
        fruitLabel.textColor = fruit == "None"
            ? UIColor.white.withAlphaComponent(0.4) : Theme.gold

        ageLabel.text       = character.age?.isEmpty == false ? character.age! : "Unknown"
        birthdayLabel.text  = character.birthday?.isEmpty == false ? character.birthday! : "Unknown"
        bloodTypeLabel.text = character.bloodType?.isEmpty == false ? character.bloodType! : "Unknown"
        originLabel.text    = character.origin?.isEmpty == false ? character.origin! : "Unknown"
        debutLabel.text     = character.debut?.isEmpty == false ? character.debut! : "Unknown"

        // Hero badges
        dfTypeBadge.text = fruit == "None" ? "  NO FRUIT  " : "  " + fruit.uppercased() + "  "
        dfTypeBadge.backgroundColor = (fruit == "None")
            ? UIColor.black.withAlphaComponent(0.55)
            : Theme.accentColor(for: character.crewTheme).withAlphaComponent(0.85)

        if let origin = character.origin, !origin.isEmpty {
            originBadge.text = "  \(origin.uppercased())  "
            originBadge.isHidden = false
        } else {
            originBadge.isHidden = true
        }

        // Bio — placeholder when missing
        if let desc = character.description, !desc.isEmpty {
            bioLabel.text      = desc
            bioLabel.textColor = UIColor.white.withAlphaComponent(0.78)
        } else {
            bioLabel.text      = "No biography available."
            bioLabel.textColor = UIColor.white.withAlphaComponent(0.35)
        }

        // Initials fallback
        initialsLabel.text = character.name
            .split(separator: " ").prefix(2)
            .compactMap { $0.first }.map(String.init).joined()
    }

    private func updateFavoriteButton() {
        let isFav = PlistService.shared.isFavorite(id: character.id)
        favoriteButton.setTitle(isFav ? "★  Remove from Favorites"
                                      : "☆  Save to Favorites", for: .normal)
        favoriteButton.backgroundColor = isFav
            ? UIColor(red:0.64,green:0.18,blue:0.18,alpha:1) : Theme.gold
        favoriteButton.setTitleColor(
            isFav ? .white : UIColor(red:0.1,green:0.1,blue:0.1,alpha:1), for: .normal)
    }

    // Image loading
    private func loadImage() {
        guard let urlStr = character.bestImageURL, let url = URL(string: urlStr) else {
            initialsView.isHidden    = false
            heroImageView.isHidden   = true
            return
        }
        initialsView.isHidden    = true
        heroImageView.isHidden   = false

        if let cached = ImageCache.shared.image(for: url) {
            heroImageView.image = cached; return
        }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let img = UIImage(data: data) else {
                DispatchQueue.main.async {
                    self?.initialsView.isHidden  = false
                    self?.heroImageView.isHidden = true
                }
                return
            }
            ImageCache.shared.store(img, for: url)
            DispatchQueue.main.async {
                self?.heroImageView.image    = img
                self?.initialsView.isHidden  = true
                self?.heroImageView.isHidden = false
            }
        }.resume()
    }

    // Actions
    @objc private func favoriteTapped() {
        _ = PlistService.shared.toggleFavorite(id: character.id)
        updateFavoriteButton()
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        UIView.animate(withDuration: 0.1, animations: {
            self.favoriteButton.transform = CGAffineTransform(scaleX: 0.96, y: 0.96)
        }) { _ in UIView.animate(withDuration: 0.1) { self.favoriteButton.transform = .identity } }
    }

    @objc private func shareTapped() {
        let text = "\(character.name) — \(character.crewDisplayName) — One Piece Explorer"
        let activity = UIActivityViewController(activityItems: [text], applicationActivities: nil)
        activity.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItem
        present(activity, animated: true)
    }
}

// PaddedLabel
// UILabel with internal padding so the badge backgrounds aren't tight against text.

final class PaddedLabel: UILabel {
    var padding: UIEdgeInsets = .zero {
        didSet { invalidateIntrinsicContentSize() }
    }
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: padding))
    }
    override var intrinsicContentSize: CGSize {
        let s = super.intrinsicContentSize
        return CGSize(width:  s.width  + padding.left + padding.right,
                      height: s.height + padding.top  + padding.bottom)
    }
}
