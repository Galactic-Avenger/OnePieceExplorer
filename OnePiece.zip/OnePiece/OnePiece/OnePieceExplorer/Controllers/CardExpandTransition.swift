import UIKit

// CardExpandTransition
// Custom navigation push animation — the tapped card visually "expands"
// up into the detail screen's hero area instead of sliding in from the side.
//
// Below I explained how it works
//  1. Take a snapshot UIImage of the tapped card (uses CharacterCardCell.snapshotImage()).
//  2. Place a UIImageView with that snapshot on top of the destination VC at the card's
//     original position in window coordinates.
//  3. Hide the destination's character so it doesn't double-show during the morph.
//  4. Animate the snapshot to fill the character rect at the top of the screen, while
//     fading the detail VC in underneath.
//  5. Remove the snapshot once it reaches its final frame; reveal the real character.

final class CardExpandTransition: NSObject, UIViewControllerAnimatedTransitioning {

    private let sourceFrame: CGRect       // card frame converted to window coords
    private let sourceImage: UIImage?     // snapshot of the card
    private let heroHeight: CGFloat = 280 // matches CharacterDetailViewController.headerMaxHeight

    init(sourceFrame: CGRect, sourceImage: UIImage?) {
        self.sourceFrame = sourceFrame
        self.sourceImage = sourceImage
    }

    func transitionDuration(using _: UIViewControllerContextTransitioning?) -> TimeInterval { 0.55 }

    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let container = transitionContext.containerView
        guard let toVC   = transitionContext.viewController(forKey: .to),
              let toView = transitionContext.view(forKey: .to) else {
            transitionContext.completeTransition(false); return
        }

        // Set up the destination view
        let finalFrame = transitionContext.finalFrame(for: toVC)
        toView.frame   = finalFrame
        toView.alpha   = 0
        container.addSubview(toView)

        // Place the card snapshot over the destination at the card's original spot
        let snap = UIImageView(image: sourceImage)
        snap.frame              = sourceFrame
        snap.contentMode        = .scaleAspectFill
        snap.clipsToBounds      = true
        snap.layer.cornerRadius = 13
        container.addSubview(snap)

        // Where the snapshot should land — full-width hero strip at the top
        let targetFrame = CGRect(x: finalFrame.minX,
                                 y: finalFrame.minY,
                                 width: finalFrame.width,
                                 height: heroHeight)

        UIView.animate(withDuration: transitionDuration(using: transitionContext),
                       delay: 0,
                       usingSpringWithDamping: 0.85,
                       initialSpringVelocity: 0.2,
                       options: [.curveEaseInOut],
                       animations: {
            snap.frame              = targetFrame
            snap.layer.cornerRadius = 0
            toView.alpha            = 1
        }, completion: { _ in
            snap.removeFromSuperview()
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        })
    }
}
