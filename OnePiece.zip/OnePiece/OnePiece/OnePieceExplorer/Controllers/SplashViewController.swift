import UIKit
import AVFoundation

// SplashViewController
// Sits between the static launch screen and the main tab bar. Uses the SAME
// Luffy image as the launch screen so the transition from launch → splash is
// invisible. Plays Bink's Sake, fades in the title, then crossfades to the app
// after 5 seconds (or immediately if the user taps).

final class SplashViewController: UIViewController {

    // UI
    private let backgroundImageView = UIImageView()
    private let darkOverlay         = UIView()
    private let titleLabel          = UILabel()
    private let subtitleLabel       = UILabel()

    // Audio
    // AVAudioPlayer is part of AVFoundation — a native iOS framework thus no third-party libraries needed. It Satisfies the term project's native only rule.
    private var audioPlayer: AVAudioPlayer?

    //Timing
    private let splashDuration: TimeInterval = 10.0
    private var hasTransitioned = false   // guard against tap-skip + timer racing

    //  Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupBackground()
        setupTitleAndSubtitle()
        setupTapToSkip()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        playAudio()
        animateTitleIn()
        scheduleTransition()
    }

    // Background
    // The same image as the launch screen, scaled aspect-fill so it fills any
    // device. A subtle dark overlay sits on top so the gold title stays legible.
    private func setupBackground() {
        backgroundImageView.image           = UIImage(named: "LuffySplash")
        backgroundImageView.contentMode     = .scaleAspectFill
        backgroundImageView.clipsToBounds   = true
        backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(backgroundImageView)

        darkOverlay.backgroundColor = UIColor.black.withAlphaComponent(0.25)
        darkOverlay.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(darkOverlay)

        NSLayoutConstraint.activate([
            backgroundImageView.topAnchor.constraint(equalTo: view.topAnchor),
            backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            backgroundImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            darkOverlay.topAnchor.constraint(equalTo: view.topAnchor),
            darkOverlay.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            darkOverlay.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            darkOverlay.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }

    // Title + subtitle
    // Placed near the top — Luffy is in the lower half of the image so the
    // upper "sky" area is the natural spot for text without covering him.
    private func setupTitleAndSubtitle() {
        titleLabel.text          = "ONE PIECE EXPLORER"
        titleLabel.font          = .systemFont(ofSize: 30, weight: .heavy)
        titleLabel.textColor     = Theme.gold
        titleLabel.textAlignment = .center
        titleLabel.alpha         = 0
        titleLabel.adjustsFontSizeToFitWidth = true
        titleLabel.minimumScaleFactor        = 0.6

        // Subtle gold glow around the title for the dramatic effect
        titleLabel.layer.shadowColor   = Theme.gold.cgColor
        titleLabel.layer.shadowRadius  = 14
        titleLabel.layer.shadowOpacity = 0.8
        titleLabel.layer.shadowOffset  = .zero
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)

        subtitleLabel.text          = "An adventure awaits..."
        subtitleLabel.font          = .italicSystemFont(ofSize: 14)
        subtitleLabel.textColor     = UIColor.white.withAlphaComponent(0.85)
        subtitleLabel.textAlignment = .center
        subtitleLabel.alpha         = 0
        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(subtitleLabel)

        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 70),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),

            subtitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            subtitleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 32),
            subtitleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -32),
        ])
    }

    //Tap to skip
    private func setupTapToSkip() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(splashTapped))
        view.addGestureRecognizer(tap)
    }

    //  Audio
    // Uses .ambient category so audio respects the silent switch — if the user
    // has their phone muted the splash will be silent rather than blaring out.
    private func playAudio() {
        guard let url = Bundle.main.url(forResource: "binks_sake", withExtension: "mp3") else {
            print("Splash: binks_sake.mp3 not found in bundle")
            return
        }
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient)
            try AVAudioSession.sharedInstance().setActive(true)
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.prepareToPlay()
            audioPlayer?.volume = 1.0
            audioPlayer?.play()
        } catch {
            // Silent fail — the splash still works visually if audio breaks
            print("Splash audio failed: \(error)")
        }
    }

    // Title animation
    private func animateTitleIn() {
        UIView.animate(withDuration: 1.0, delay: 0.3, options: .curveEaseOut) {
            self.titleLabel.alpha = 1
        }
        UIView.animate(withDuration: 0.8, delay: 1.0, options: .curveEaseOut) {
            self.subtitleLabel.alpha = 1
        }
    }

    // Transition
    private func scheduleTransition() {
        DispatchQueue.main.asyncAfter(deadline: .now() + splashDuration) { [weak self] in
            self?.transitionToMainApp()
        }
    }

    @objc private func splashTapped() {
        transitionToMainApp()
    }

    private func transitionToMainApp() {
        // Guard against the tap+timer both firing
        guard !hasTransitioned else { return }
        hasTransitioned = true

        fadeOutAudio()

        guard let window = view.window else { return }
        let tabBar = MainTabBarController()
        UIView.transition(with: window,
                          duration: 0.5,
                          options: .transitionCrossDissolve) {
            window.rootViewController = tabBar
        }
    }

    // Smooth volume fadeout — chunks the fade into 20 small steps over 0.5s so
    // the audio doesn't cut off abruptly when the visual crossfade starts.
    private func fadeOutAudio() {
        guard let player = audioPlayer, player.isPlaying else { return }
        let fadeSteps      = 20
        let interval       = 0.5 / Double(fadeSteps)
        let initialVolume  = player.volume
        for step in 1...fadeSteps {
            DispatchQueue.main.asyncAfter(deadline: .now() + interval * Double(step)) { [weak player] in
                player?.volume = initialVolume * (1.0 - Float(step) / Float(fadeSteps))
                if step == fadeSteps { player?.stop() }
            }
        }
    }
}
