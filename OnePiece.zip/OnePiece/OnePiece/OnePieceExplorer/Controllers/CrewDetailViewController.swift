import UIKit

// CrewDetailViewController
// Shows the canonical roster for a specific crew. For each canonical name we
// fire off a parallel API search; matches replace the placeholder card, misses
// stay as a "limited info" placeholder. The collection view always has the
// full roster count (so it never looks half-loaded).

final class CrewDetailViewController: UIViewController {

    private let crew: CrewInfo
    private var members: [Character] = []     // always has crew.coreMembers.count entries
    private var pendingTransition: CardExpandTransition?

    init(crew: CrewInfo) {
        self.crew = crew
        // Seed with placeholders so the collection view has rows immediately
        self.members = crew.coreMembers.map {
            Canon.placeholderCharacter(name: $0, affiliations: crew.name)
        }
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError() }

    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 12
        layout.minimumLineSpacing      = 14
        layout.sectionInset            = UIEdgeInsets(top: 16, left: 14, bottom: 24, right: 14)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.backgroundColor = Theme.pageBG
        cv.alwaysBounceVertical = true
        cv.register(CharacterCardCell.self, forCellWithReuseIdentifier: CharacterCardCell.reuseID)
        cv.dataSource = self
        cv.delegate   = self
        cv.translatesAutoresizingMaskIntoConstraints = false
        return cv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = crew.name
        Theme.applyNavBar(to: navigationController)
        view.backgroundColor = Theme.pageBG

        view.addSubview(collectionView)
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])

        fetchRoster()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.delegate = self
    }

    // Fetch roster
    // One API search per canonical name, all in parallel. As each comes back,
    // we replace that slot's placeholder with the real character and reload
    // just that row so the user sees progressive population.
    private func fetchRoster() {
        for (index, canonicalName) in crew.coreMembers.enumerated() {
            APIService.shared.searchCharacters(name: canonicalName) { [weak self] result in
                guard case .success(let matches) = result, !matches.isEmpty else { return }
                let best = self?.bestMatch(for: canonicalName, in: matches)
                guard let real = best else { return }
                DispatchQueue.main.async {
                    guard let self = self, index < self.members.count else { return }
                    self.members[index] = real
                    let path = IndexPath(item: index, section: 0)
                    if self.collectionView.indexPathsForVisibleItems.contains(path) {
                        self.collectionView.reloadItems(at: [path])
                    }
                }
            }
        }
    }

    // Pick the best match — prefer exact name (case-insensitive), otherwise
    // the first result. The API's name filter is a substring search so multiple
    // hits are common (e.g. "Sanji" returns Sanji + Sanjuan Wolf).
    private func bestMatch(for canonicalName: String, in matches: [Character]) -> Character? {
        let target = canonicalName.lowercased()
        if let exact = matches.first(where: { $0.name.lowercased() == target }) { return exact }
        // Then prefer one whose name contains the canonical name
        if let contains = matches.first(where: { $0.name.lowercased().contains(target) }) { return contains }
        return matches.first
    }
}

extension CrewDetailViewController: UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int { members.count }
    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: CharacterCardCell.reuseID,
                                           for: indexPath) as! CharacterCardCell
        cell.configure(with: members[indexPath.item])
        return cell
    }
}

extension CrewDetailViewController: UICollectionViewDelegate {
    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = cv.cellForItem(at: indexPath) as? CharacterCardCell
        if let cell = cell, let window = cell.window {
            let frame = cell.convert(cell.bounds, to: window)
            pendingTransition = CardExpandTransition(sourceFrame: frame, sourceImage: cell.snapshotImage())
        }
        let detail = CharacterDetailViewController(character: members[indexPath.item])
        navigationController?.pushViewController(detail, animated: true)
    }
}

extension CrewDetailViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ cv: UICollectionView, layout _: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding: CGFloat = 14 * 2 + 12
        let width            = (cv.bounds.width - padding) / 2
        return CGSize(width: width, height: width * 1.45)
    }
}

extension CrewDetailViewController: UINavigationControllerDelegate {
    func navigationController(_ nc: UINavigationController,
                              animationControllerFor operation: UINavigationController.Operation,
                              from: UIViewController, to: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        guard operation == .push, let t = pendingTransition else { return nil }
        pendingTransition = nil
        return t
    }
}
