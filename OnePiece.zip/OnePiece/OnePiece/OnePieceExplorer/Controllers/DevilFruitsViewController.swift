import UIKit

// DevilFruitsViewController
// Grid of all Devil Fruits from the API. Tap one to see its detail page
// with owner history, description, debut, etc.

final class DevilFruitsViewController: UIViewController {

    private var fruits: [DevilFruit] = []
    private var currentPage   = 1
    private var isLoadingMore = false

    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 12
        layout.minimumLineSpacing      = 14
        layout.sectionInset            = UIEdgeInsets(top: 12, left: 14, bottom: 24, right: 14)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.backgroundColor = Theme.pageBG
        cv.alwaysBounceVertical = true
        cv.register(DevilFruitCell.self, forCellWithReuseIdentifier: DevilFruitCell.reuseID)
        cv.dataSource = self
        cv.delegate   = self
        cv.translatesAutoresizingMaskIntoConstraints = false
        return cv
    }()

    private let loadingIndicator: UIActivityIndicatorView = {
        let ai = UIActivityIndicatorView(style: .large)
        ai.color = Theme.gold
        ai.hidesWhenStopped = true
        ai.translatesAutoresizingMaskIntoConstraints = false
        return ai
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Devil Fruits"
        navigationController?.navigationBar.prefersLargeTitles = true
        Theme.applyNavBar(to: navigationController)
        view.backgroundColor = Theme.pageBG

        view.addSubview(collectionView)
        view.addSubview(loadingIndicator)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            loadingIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        ])

        fetchFruits()
    }

    private func fetchFruits() {
        if currentPage == 1 { loadingIndicator.startAnimating() }
        APIService.shared.fetchDevilFruits(page: currentPage) { [weak self] result in
            DispatchQueue.main.async {
                self?.loadingIndicator.stopAnimating()
                self?.isLoadingMore = false
                if case .success(let newFruits) = result {
                    let existingIDs = Set(self?.fruits.map { $0.id } ?? [])
                    let unseen = newFruits.filter { !existingIDs.contains($0.id) }
                    self?.fruits.append(contentsOf: unseen)
                    self?.collectionView.reloadData()
                }
            }
        }
    }
}

extension DevilFruitsViewController: UICollectionViewDataSource {
    func collectionView(_ cv: UICollectionView, numberOfItemsInSection s: Int) -> Int { fruits.count }
    func collectionView(_ cv: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cv.dequeueReusableCell(withReuseIdentifier: DevilFruitCell.reuseID,
                                           for: indexPath) as! DevilFruitCell
        cell.configure(with: fruits[indexPath.item])
        return cell
    }
}

extension DevilFruitsViewController: UICollectionViewDelegate {
    func collectionView(_ cv: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        let detail = DevilFruitDetailViewController(fruit: fruits[indexPath.item])
        navigationController?.pushViewController(detail, animated: true)
    }

    // Pagination — load more when near the bottom
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offset    = scrollView.contentOffset.y
        let height    = scrollView.contentSize.height
        let threshold = height - scrollView.frame.height - 200
        if offset > threshold && !isLoadingMore && !fruits.isEmpty {
            isLoadingMore = true
            currentPage  += 1
            fetchFruits()
        }
    }
}

extension DevilFruitsViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ cv: UICollectionView, layout _: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding: CGFloat = 14 * 2 + 12
        let width            = (cv.bounds.width - padding) / 2
        return CGSize(width: width, height: width * 1.25)
    }
}

// DevilFruitCell

final class DevilFruitCell: UICollectionViewCell {
    static let reuseID = "DevilFruitCell"

    private let imageView   = UIImageView()
    private let nameLabel   = UILabel()
    private let typeBadge   = PaddedLabel()
    private let meaningLbl  = UILabel()
    private let initialsLbl = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        contentView.layer.cornerRadius = 14
        contentView.clipsToBounds = true
    }

    private func setup() {
        contentView.backgroundColor    = Theme.cardBG
        contentView.layer.cornerRadius = 14
        contentView.layer.borderWidth  = 0.5
        contentView.layer.borderColor  = UIColor.white.withAlphaComponent(0.1).cgColor

        imageView.contentMode     = .scaleAspectFit
        imageView.clipsToBounds   = true
        imageView.backgroundColor = .clear
        imageView.translatesAutoresizingMaskIntoConstraints = false

        initialsLbl.font          = .systemFont(ofSize: 38, weight: .heavy)
        initialsLbl.textAlignment = .center
        initialsLbl.textColor     = UIColor.white.withAlphaComponent(0.25)
        initialsLbl.translatesAutoresizingMaskIntoConstraints = false

        typeBadge.font              = .systemFont(ofSize: 9, weight: .heavy)
        typeBadge.textColor         = .white
        typeBadge.layer.cornerRadius = 5
        typeBadge.layer.masksToBounds = true
        typeBadge.padding            = UIEdgeInsets(top: 2, left: 6, bottom: 2, right: 6)
        typeBadge.translatesAutoresizingMaskIntoConstraints = false

        nameLabel.font          = .systemFont(ofSize: 12, weight: .heavy)
        nameLabel.textColor     = .white
        nameLabel.textAlignment = .center
        nameLabel.numberOfLines = 2
        nameLabel.adjustsFontSizeToFitWidth = true
        nameLabel.minimumScaleFactor        = 0.6
        nameLabel.translatesAutoresizingMaskIntoConstraints = false

        meaningLbl.font          = .systemFont(ofSize: 10)
        meaningLbl.textColor     = UIColor.white.withAlphaComponent(0.55)
        meaningLbl.textAlignment = .center
        meaningLbl.numberOfLines = 1
        meaningLbl.adjustsFontSizeToFitWidth = true
        meaningLbl.minimumScaleFactor        = 0.6
        meaningLbl.translatesAutoresizingMaskIntoConstraints = false

        contentView.addSubview(imageView)
        contentView.addSubview(initialsLbl)
        contentView.addSubview(typeBadge)
        contentView.addSubview(nameLabel)
        contentView.addSubview(meaningLbl)

        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 14),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -14),
            imageView.heightAnchor.constraint(equalTo: contentView.heightAnchor, multiplier: 0.55),

            initialsLbl.centerXAnchor.constraint(equalTo: imageView.centerXAnchor),
            initialsLbl.centerYAnchor.constraint(equalTo: imageView.centerYAnchor),

            typeBadge.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 6),
            typeBadge.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),

            nameLabel.topAnchor.constraint(equalTo: typeBadge.bottomAnchor, constant: 4),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),

            meaningLbl.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            meaningLbl.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            meaningLbl.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            meaningLbl.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -8),
        ])
    }

    func configure(with fruit: DevilFruit) {
        nameLabel.text   = fruit.name
        meaningLbl.text  = fruit.meaning ?? ""
        typeBadge.text   = "  " + (fruit.type ?? "Unknown").uppercased() + "  "
        typeBadge.backgroundColor = fruit.typeBadgeColor()

        initialsLbl.text = String(fruit.name.prefix(1))
        loadImage(from: fruit.avatarSrc)
    }

    private var imageTask: URLSessionDataTask?
    private func loadImage(from urlString: String?) {
        imageTask?.cancel()
        imageView.image = nil
        initialsLbl.isHidden = false
        guard let s = urlString, let url = URL(string: s) else { return }
        if let cached = ImageCache.shared.image(for: url) {
            imageView.image = cached
            initialsLbl.isHidden = true
            return
        }
        imageTask = URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let img = UIImage(data: data) else { return }
            ImageCache.shared.store(img, for: url)
            DispatchQueue.main.async {
                self?.imageView.image = img
                self?.initialsLbl.isHidden = true
            }
        }
        imageTask?.resume()
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        imageTask?.cancel()
        imageView.image = nil
        initialsLbl.isHidden = false
    }

    override var isHighlighted: Bool {
        didSet {
            UIView.animate(withDuration: 0.12) {
                self.transform = self.isHighlighted
                    ? CGAffineTransform(scaleX: 0.95, y: 0.95) : .identity
            }
        }
    }
}
