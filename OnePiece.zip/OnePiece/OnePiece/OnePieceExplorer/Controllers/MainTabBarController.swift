import UIKit

// MainTabBarController
// Four tabs: Explore (characters/crews/fruits) — Wanted — Quiz — Favorites

final class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabs()
        styleTabBar()
    }

    private func setupTabs() {
        let explore     = makeNav(root: CharactersViewController(),
                                  title: "Explore",
                                  image: "magnifyingglass",
                                  tag: 0)

        let wanted      = makeNav(root: LeaderboardViewController(),
                                  title: "Wanted",
                                  image: "scroll.fill",
                                  tag: 1)

        let quiz        = makeNav(root: QuizViewController(),
                                  title: "Quiz",
                                  image: "questionmark.circle.fill",
                                  tag: 2)

        let favorites   = makeNav(root: FavoritesViewController(),
                                  title: "Favorites",
                                  image: "star.fill",
                                  tag: 3)

        viewControllers = [explore, wanted, quiz, favorites]
    }

    private func makeNav(root: UIViewController,
                         title: String,
                         image: String,
                         tag: Int) -> UINavigationController {
        root.title = title
        let nav    = UINavigationController(rootViewController: root)
        nav.tabBarItem = UITabBarItem(title: title,
                                      image: UIImage(systemName: image),
                                      tag: tag)
        return nav
    }

    private func styleTabBar() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(red:0.05, green:0.09, blue:0.14, alpha:1)

        appearance.stackedLayoutAppearance.selected.iconColor   = Theme.gold
        appearance.stackedLayoutAppearance.selected.titleTextAttributes = [
            .foregroundColor: Theme.gold,
            .font: UIFont.systemFont(ofSize: 10, weight: .semibold)
        ]
        let dimmed = UIColor.white.withAlphaComponent(0.4)
        appearance.stackedLayoutAppearance.normal.iconColor   = dimmed
        appearance.stackedLayoutAppearance.normal.titleTextAttributes = [
            .foregroundColor: dimmed,
            .font: UIFont.systemFont(ofSize: 10)
        ]

        tabBar.standardAppearance   = appearance
        tabBar.scrollEdgeAppearance = appearance
        tabBar.tintColor            = Theme.gold
    }
}
