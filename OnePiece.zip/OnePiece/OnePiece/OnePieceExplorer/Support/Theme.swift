import UIKit

//  Theme

struct Theme {

    static let gold     = UIColor(red: 0.94, green: 0.62, blue: 0.09, alpha: 1)
    static let goldDark = UIColor(red: 0.73, green: 0.46, blue: 0.04, alpha: 1)
    static let pageBG   = UIColor(red: 0.04, green: 0.08, blue: 0.12, alpha: 1)
    static let cardBG   = UIColor(red: 0.07, green: 0.12, blue: 0.18, alpha: 1)
    static let navBG    = UIColor(red: 0.05, green: 0.09, blue: 0.14, alpha: 1)

    static func cardGradientColors(for theme: CrewTheme) -> (UIColor, UIColor) {
        switch theme {
        case .strawHats:    return (UIColor(red:0.10,green:0.23,blue:0.36,alpha:1),
                                    UIColor(red:0.05,green:0.14,blue:0.25,alpha:1))
        case .marines:      return (UIColor(red:0.10,green:0.16,blue:0.29,alpha:1),
                                    UIColor(red:0.05,green:0.10,blue:0.19,alpha:1))
        case .beastPirates: return (UIColor(red:0.23,green:0.10,blue:0.10,alpha:1),
                                    UIColor(red:0.13,green:0.05,blue:0.05,alpha:1))
        case .bigMom:       return (UIColor(red:0.23,green:0.10,blue:0.23,alpha:1),
                                    UIColor(red:0.13,green:0.05,blue:0.13,alpha:1))
        case .whitebeard:   return (UIColor(red:0.10,green:0.10,blue:0.23,alpha:1),
                                    UIColor(red:0.05,green:0.05,blue:0.13,alpha:1))
        case .roger:        return (UIColor(red:0.20,green:0.15,blue:0.05,alpha:1),
                                    UIColor(red:0.12,green:0.09,blue:0.02,alpha:1))
        case .doflamingo:   return (UIColor(red:0.25,green:0.05,blue:0.12,alpha:1),
                                    UIColor(red:0.15,green:0.02,blue:0.07,alpha:1))
        case .heartPirates: return (UIColor(red:0.05,green:0.18,blue:0.22,alpha:1),
                                    UIColor(red:0.02,green:0.10,blue:0.13,alpha:1))
        case .blackbeard:   return (UIColor(red:0.08,green:0.08,blue:0.10,alpha:1),
                                    UIColor(red:0.03,green:0.03,blue:0.05,alpha:1))
        case .revolutionary:return (UIColor(red:0.25,green:0.10,blue:0.05,alpha:1),
                                    UIColor(red:0.15,green:0.05,blue:0.02,alpha:1))
        case .unknown:      return (UIColor(red:0.10,green:0.10,blue:0.13,alpha:1),
                                    UIColor(red:0.06,green:0.06,blue:0.08,alpha:1))
        }
    }

    static func accentColor(for theme: CrewTheme) -> UIColor {
        switch theme {
        case .strawHats:    return gold
        case .marines:      return UIColor(red:0.36,green:0.79,blue:0.65,alpha:1)
        case .beastPirates: return UIColor(red:0.89,green:0.30,blue:0.29,alpha:1)
        case .bigMom:       return UIColor(red:0.93,green:0.55,blue:0.75,alpha:1)
        case .whitebeard:   return UIColor(red:0.52,green:0.60,blue:0.85,alpha:1)
        case .roger:        return UIColor(red:0.95,green:0.75,blue:0.20,alpha:1)
        case .doflamingo:   return UIColor(red:0.95,green:0.35,blue:0.55,alpha:1)
        case .heartPirates: return UIColor(red:0.30,green:0.75,blue:0.85,alpha:1)
        case .blackbeard:   return UIColor(red:0.55,green:0.40,blue:0.65,alpha:1)
        case .revolutionary:return UIColor(red:0.95,green:0.40,blue:0.20,alpha:1)
        case .unknown:      return UIColor(red:0.53,green:0.53,blue:0.50,alpha:1)
        }
    }

    static func rarityColor(for rarity: Rarity) -> UIColor {
        switch rarity {
        case .ur:  return gold
        case .ssr: return UIColor(red:0.89,green:0.30,blue:0.29,alpha:1)
        case .sr:  return UIColor(red:0.36,green:0.79,blue:0.65,alpha:1)
        }
    }

    static func glowColor(for rarity: Rarity) -> UIColor {
        switch rarity {
        case .ur:  return gold.withAlphaComponent(0.6)
        case .ssr: return UIColor(red:0.89,green:0.30,blue:0.29,alpha:0.5)
        case .sr:  return UIColor.clear
        }
    }

    static func applyGlow(to view: UIView, rarity: Rarity) {
        view.layer.shadowColor   = Theme.glowColor(for: rarity).cgColor
        view.layer.shadowRadius  = rarity == .ur ? 12 : 7
        view.layer.shadowOpacity = rarity == .sr ? 0 : 1.0
        view.layer.shadowOffset  = .zero
    }

    static func applyGradient(to layer: CAGradientLayer, theme: CrewTheme) {
        let (top, bottom) = cardGradientColors(for: theme)
        layer.colors      = [top.cgColor, bottom.cgColor]
        layer.startPoint  = CGPoint(x: 0.2, y: 0)
        layer.endPoint    = CGPoint(x: 0.8, y: 1)
    }

    static func applyNavBar(to navController: UINavigationController?) {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor          = navBG
        appearance.titleTextAttributes      = [.foregroundColor: gold,
                                               .font: UIFont.systemFont(ofSize: 17, weight: .bold)]
        appearance.largeTitleTextAttributes = [.foregroundColor: gold,
                                               .font: UIFont.systemFont(ofSize: 30, weight: .bold)]
        navController?.navigationBar.standardAppearance   = appearance
        navController?.navigationBar.scrollEdgeAppearance = appearance
        navController?.navigationBar.tintColor            = gold
    }
}
