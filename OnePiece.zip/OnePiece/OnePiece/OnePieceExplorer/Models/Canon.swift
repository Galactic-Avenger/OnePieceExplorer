import Foundation

// Canon
// This canonical One Piece data that overrides whatever the API returns that isnt canon.
// The API is solid for general character data but isn't authoritative on bounties or crew rosters, so I kept this list for the things that matter.

struct Canon {

    //  Canon bounties
    // When any Character whose name matches one of these keys is loaded, this
    // bounty is used instead of whatever the API returned. The lookup is wired
    // into Character.bountyValue, so the override propagates to every screen
    // automatically — cards, leaderboard, wanted posters, detail page.
    //
    // Aliases are included so the dictionary matches whichever form the API
    // returns (some characters are known by multiple names).
    static let canonicalBounties: [String: Int] = [
        // Pirate King + Yonko-tier
        "Gol D. Roger":              5_564_800_000,
        "Edward Newgate":            5_046_000_000,
        "Whitebeard":                5_046_000_000,
        "Kaido":                     4_611_100_000,
        "Charlotte Linlin":          4_388_000_000,
        "Big Mom":                   4_388_000_000,
        "Shanks":                    4_048_900_000,
        "Marshall D. Teach":         3_996_000_000,
        "Blackbeard":                3_996_000_000,

        // Cross Guild + Current Yonko-tier
        "Dracule Mihawk":            3_590_000_000,
        "Buggy":                     3_189_000_000,
        "Buggy the Clown":           3_189_000_000,
        "Monkey D. Luffy":           3_000_000_000,
        "Luffy":                     3_000_000_000,
        "Trafalgar Law":             3_000_000_000,
        "Trafalgar D. Water Law":    3_000_000_000,
        "Eustass Kid":               3_000_000_000,
        "Eustass \"Captain\" Kid":   3_000_000_000,

        // Lower than Yonko
        "Crocodile":                 1_965_000_000,
        "Sir Crocodile":             1_965_000_000,
        "Boa Hancock":               1_659_000_000,
        "King":                      1_390_000_000,
        "Marco":                     1_374_000_000,
        "Queen":                     1_320_000_000,
        "Roronoa Zoro":              1_111_000_000,
        "Zoro":                      1_111_000_000,
        "Jinbe":                     1_100_000_000,
        "Charlotte Katakuri":        1_057_000_000,
        "Vinsmoke Sanji":            1_032_000_000,
        "Sanji":                     1_032_000_000,
        "Jack":                      1_000_000_000,
        "Jack the Drought":          1_000_000_000,
        "Charlotte Smoothie":        932_000_000,
        "Nico Robin":                930_000_000,
        "Robin":                     930_000_000,
        "Charlotte Cracker":         860_000_000,
        "Charlotte Perospero":       700_000_000,
        "Sabo":                      602_000_000,
        "Portgas D. Ace":            550_000_000,
        "Ace":                       550_000_000,

        // Other Straw Hats
        "Usopp":                     500_000_000,
        "God Usopp":                 500_000_000,
        "Franky":                    394_000_000,
        "Brook":                     383_000_000,
        "Nami":                      366_000_000,
        "Tony Tony Chopper":         1_000,
        "Chopper":                   1_000,

        //  others
        "Donquixote Doflamingo":     340_000_000,
        "Doflamingo":                340_000_000,
    ]

    // Lookup
    // Used by Character.bountyValue. Returns the canonical bounty for a known
    // character name, or nil if we don't override this one.
    static func canonicalBounty(forName name: String) -> Int? {
        // Exact match
        if let v = canonicalBounties[name], v > 0 { return v }
        // Case-insensitive
        let lower = name.lowercased()
        for (key, value) in canonicalBounties {
            if key.lowercased() == lower && value > 0 { return value }
        }
        return nil
    }

    // Wanted Top 25
    // Pre-sorted descending by canonical bounty. The Wanted leaderboard renders
    // this list in this exact order — no API-side sorting needed since these
    // names are mapped to their canonical bounties above.
    static let wantedTop25: [String] = [
        "Gol D. Roger",            // 5.564B
        "Edward Newgate",          // 5.046B
        "Kaido",                   // 4.611B
        "Charlotte Linlin",        // 4.388B
        "Shanks",                  // 4.048B
        "Marshall D. Teach",       // 3.996B
        "Dracule Mihawk",          // 3.590B
        "Buggy",                   // 3.189B
        "Monkey D. Luffy",         // 3.000B
        "Trafalgar Law",           // 3.000B
        "Eustass Kid",             // 3.000B
        "Crocodile",               // 1.965B
        "Boa Hancock",             // 1.659B
        "King",                    // 1.390B
        "Marco",                   // 1.374B
        "Queen",                   // 1.320B
        "Roronoa Zoro",            // 1.111B
        "Jinbe",                   // 1.100B
        "Charlotte Katakuri",      // 1.057B
        "Vinsmoke Sanji",          // 1.032B
        "Jack",                    // 1.000B
        "Charlotte Smoothie",      // 932M
        "Nico Robin",              // 930M
        "Charlotte Cracker",       // 860M
        "Charlotte Perospero",     // 700M
    ]

    // Placeholder character builder
    // When a canonical roster member can't be found via the API, we render them
    // as a placeholder card with just their name + affiliation. The placeholder
    // has a stable negative ID derived from the name hash so collection view
    // diffing stays consistent across reloads within a session.
    static func placeholderCharacter(name: String, affiliations: String? = nil) -> Character {
        let fakeID = -1 - abs(name.hashValue % 1_000_000)
        return Character(
            id: fakeID,
            englishName: name,
            japaneseName: nil,
            bounty: nil,
            age: nil,
            birthday: nil,
            bloodType: nil,
            origin: nil,
            debut: nil,
            devilFruitName: nil,
            description: "Limited information available for this character.",
            affiliations: affiliations,
            avatarSrc: nil
        )
    }
}
