import UIKit

//  CrewsCatalog
// The GraphQL API doesn't have crews as queryable entities and the affiliations
// field is too inconsistent to derive rosters from. So we maintain canonical
// rosters here. The Crews tab uses these directly — never API-filtered.

struct CrewInfo {
    let name: String          // "Straw Hat Pirates"
    let shortName: String     // "Straw Hats" — used as filter pill in card cells
    let theme: CrewTheme      // For tinting
    let keywords: [String]    // Substrings to match in affiliations (used by crewTheme)
    let coreMembers: [String] // Canonical roster — what the Crew Detail screen shows
    let emblem: String        // Emoji shown on the crew card
    let tagline: String       // Short descriptor
}

struct CrewsCatalog {

    // All recognized crews — order is roughly by power/bounty
    static let all: [CrewInfo] = [
        CrewInfo(name: "Straw Hat Pirates",       shortName: "Straw Hats",
                 theme: .strawHats,
                 keywords: ["straw hat"],
                 coreMembers: [
                    "Monkey D. Luffy",
                    "Roronoa Zoro",
                    "Nami",
                    "Usopp",
                    "Vinsmoke Sanji",
                    "Tony Tony Chopper",
                    "Nico Robin",
                    "Franky",
                    "Brook",
                    "Jinbe",
                 ],
                 emblem: "🏴‍☠️",
                 tagline: "The crew of Monkey D. Luffy"),

        CrewInfo(name: "Marines",                  shortName: "Marines",
                 theme: .marines,
                 keywords: ["marine", "navy"],
                 coreMembers: [
                    "Sengoku",
                    "Sakazuki",
                    "Kuzan",
                    "Borsalino",
                    "Issho",
                    "Aramaki",
                    "Monkey D. Garp",
                    "Smoker",
                    "Tashigi",
                    "Koby",
                 ],
                 emblem: "⚓",
                 tagline: "World Government enforcers"),

        CrewInfo(name: "Beast Pirates",            shortName: "Beast Pirates",
                 theme: .beastPirates,
                 keywords: ["beast", "hundred beast"],
                 coreMembers: [
                    "Kaido",
                    "King",
                    "Queen",
                    "Jack",
                    "Yamato",
                    "Who's-Who",
                    "Black Maria",
                    "Sasaki",
                    "Ulti",
                    "Page One",
                 ],
                 emblem: "🐉",
                 tagline: "Kaidō's crew of Smile users"),

        CrewInfo(name: "Big Mom Pirates",          shortName: "Big Mom",
                 theme: .bigMom,
                 keywords: ["big mom", "charlotte"],
                 coreMembers: [
                    "Charlotte Linlin",
                    "Charlotte Katakuri",
                    "Charlotte Smoothie",
                    "Charlotte Cracker",
                    "Charlotte Perospero",
                    "Charlotte Pudding",
                    "Charlotte Brulee",
                    "Charlotte Daifuku",
                    "Charlotte Oven",
                    "Charlotte Compote",
                 ],
                 emblem: "🍰",
                 tagline: "Charlotte Linlin's family"),

        CrewInfo(name: "Whitebeard Pirates",       shortName: "Whitebeard",
                 theme: .whitebeard,
                 keywords: ["whitebeard"],
                 coreMembers: [
                    "Edward Newgate",
                    "Marco",
                    "Portgas D. Ace",
                    "Jozu",
                    "Vista",
                    "Izo",
                    "Thatch",
                    "Haruta",
                    "Namur",
                    "Blamenco",
                 ],
                 emblem: "⚔️",
                 tagline: "Edward Newgate's legendary crew"),

        CrewInfo(name: "Roger Pirates",            shortName: "Roger",
                 theme: .roger,
                 keywords: ["roger"],
                 coreMembers: [
                    "Gol D. Roger",
                    "Silvers Rayleigh",
                    "Scopper Gaban",
                    "Crocus",
                    "Shanks",
                    "Buggy",
                    "Kozuki Oden",
                    "Inuarashi",
                    "Nekomamushi",
                 ],
                 emblem: "👑",
                 tagline: "Gol D. Roger's Pirate King crew"),

        CrewInfo(name: "Heart Pirates",            shortName: "Heart Pirates",
                 theme: .heartPirates,
                 keywords: ["heart"],
                 coreMembers: [
                    "Trafalgar Law",
                    "Bepo",
                    "Penguin",
                    "Shachi",
                    "Jean Bart",
                    "Ikkaku",
                    "Uni",
                    "Clione",
                 ],
                 emblem: "💛",
                 tagline: "Law's submarine crew"),

        CrewInfo(name: "Donquixote Pirates",       shortName: "Donquixote",
                 theme: .doflamingo,
                 keywords: ["donquixote", "doflamingo"],
                 coreMembers: [
                    "Donquixote Doflamingo",
                    "Trebol",
                    "Diamante",
                    "Pica",
                    "Vergo",
                    "Sugar",
                    "Monet",
                    "Baby 5",
                    "Senor Pink",
                    "Lao G",
                 ],
                 emblem: "🃏",
                 tagline: "Doflamingo's family of executives"),

        CrewInfo(name: "Blackbeard Pirates",       shortName: "Blackbeard",
                 theme: .blackbeard,
                 keywords: ["blackbeard", "teach"],
                 coreMembers: [
                    "Marshall D. Teach",
                    "Jesus Burgess",
                    "Shiryu",
                    "Van Augur",
                    "Doc Q",
                    "Laffitte",
                    "Sanjuan Wolf",
                    "Catarina Devon",
                    "Avalo Pizarro",
                    "Vasco Shot",
                 ],
                 emblem: "💀",
                 tagline: "Marshall D. Teach's dark fleet"),

        CrewInfo(name: "Revolutionary Army",       shortName: "Revolutionaries",
                 theme: .revolutionary,
                 keywords: ["revolutionary"],
                 coreMembers: [
                    "Monkey D. Dragon",
                    "Sabo",
                    "Emporio Ivankov",
                    "Bartholomew Kuma",
                    "Karasu",
                    "Belo Betty",
                    "Lindbergh",
                    "Morley",
                    "Inazuma",
                    "Koala",
                 ],
                 emblem: "🔥",
                 tagline: "Dragon's anti-government force"),
    ]

    // Used by Character.crewTheme to color cards by which crew the character belongs to.
    // The match is still keyword-based here because we're going Character → Crew (not
    // Crew → Character), and any reasonable affiliation string is fine for theming.
    static func crew(for character: Character) -> CrewInfo? {
        guard let a = character.affiliations?.lowercased() else { return nil }
        for crew in all {
            for keyword in crew.keywords {
                if a.contains(keyword) { return crew }
            }
        }
        return nil
    }
}
