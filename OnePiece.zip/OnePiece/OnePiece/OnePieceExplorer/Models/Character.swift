import Foundation
import UIKit

// Character Model
// Matches the GraphQL `character` type from onepieceql.up.railway.app.
// Fields we get from the API:
//   id, englishName, japaneseName, bounty, age, birthday, bloodType,
//   origin, debut, devilFruitName, description, affiliations, avatarSrc
//
// Fields that no longer exist (compared to the old REST API):
//   role, status (alive/dead), height, saga, crew object, fruit type
// We derive what we can from `affiliations` (crew name) and bounty value.

struct Character: Codable, Sendable {
    let id: Int
    let englishName: String?
    let japaneseName: String?
    let bounty: String?
    let age: String?
    let birthday: String?
    let bloodType: String?
    let origin: String?
    let debut: String?
    let devilFruitName: String?
    let description: String?
    let affiliations: String?
    let avatarSrc: String?

    // Display helpers
    var name: String { englishName ?? japaneseName ?? "Unknown" }

    var bestImageURL: String? { avatarSrc }

    // Rarity (still based on bounty value)
    var rarity: Rarity {
        let v = bountyValue
        if v >= 1_000_000_000 { return .ur  }
        if v >= 100_000_000   { return .ssr }
        return .sr
    }

    // Crew theme — read from affiliations string
    // Affiliations comes as something like "Straw Hat Pirates, Heart Pirates Alliance"
    var crewTheme: CrewTheme {
        guard let a = affiliations?.lowercased() else { return .unknown }
        if a.contains("straw hat")       { return .strawHats }
        if a.contains("marine")          { return .marines }
        if a.contains("beast")           { return .beastPirates }
        if a.contains("big mom") || a.contains("charlotte") { return .bigMom }
        if a.contains("whitebeard")      { return .whitebeard }
        if a.contains("roger")           { return .roger }
        if a.contains("donquixote") || a.contains("doflamingo") { return .doflamingo }
        if a.contains("heart")           { return .heartPirates }
        if a.contains("blackbeard")      { return .blackbeard }
        if a.contains("revolutionary")   { return .revolutionary }
        return .unknown
    }

    // English crew name — strip multiple affiliations to the primary one
    var crewDisplayName: String {
        guard let a = affiliations, !a.isEmpty else { return "Unknown" }
        // If multiple, just take the first one before the comma
        let primary = a.components(separatedBy: ",").first ?? a
        return primary.trimmingCharacters(in: .whitespaces)
    }

    // Bounty
    // Canonical override takes precedence for known characters (Roger, Whitebeard,
    // Luffy, etc.) — see Canon.canonicalBounty(forName:). For everyone else we
    // fall back to parsing the API string.
    var bountyValue: Int {
        if let canonical = Canon.canonicalBounty(forName: name) { return canonical }
        guard let b = bounty else { return 0 }
        let digits = b.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        return Int(digits) ?? 0
    }

    var bountyFormatted: String {
        guard bountyValue > 0 else { return "Unknown ฿" }
        let f = NumberFormatter()
        f.numberStyle       = .decimal
        f.groupingSeparator = ","
        return "\(f.string(from: NSNumber(value: bountyValue)) ?? "\(bountyValue)") ฿"
    }

    var bountyShort: String {
        let v = bountyValue
        guard v > 0 else { return "—" }
        switch v {
        case 1_000_000_000...: return String(format: "%.2gB ฿", Double(v) / 1_000_000_000)
        case 1_000_000...:     return "\(v / 1_000_000)M ฿"
        case 1_000...:         return "\(v / 1_000)K ฿"
        default:               return "\(v) ฿"
        }
    }

    // Age helper — strip "years old" if present
    var ageDisplay: String {
        guard let a = age, !a.isEmpty else { return "Unknown" }
        return a
    }

    // Devil Fruit display — "None" if blank/null
    var devilFruitDisplay: String {
        guard let f = devilFruitName, !f.isEmpty, f.lowercased() != "none" else { return "None" }
        return f
    }
}

// Devil Fruit Model

struct DevilFruit: Codable, Sendable {
    let id: Int
    let englishName: String?
    let japaneseName: String?
    let meaning: String?
    let type: String?               // Paramecia / Zoan / Logia / Mythical Zoan etc.
    let currentOwner: String?
    let previousOwner: String?
    let description: String?
    let usageDebut: String?
    let avatarSrc: String?

    var name: String { englishName ?? japaneseName ?? "Unknown" }
    var typeDisplay: String { type ?? "Unknown" }
}

// Supporting enums (kept for compatibility with old code)

enum Rarity: String {
    case ur = "UR", ssr = "SSR", sr = "SR"
}

enum CrewTheme {
    case strawHats, marines, beastPirates, bigMom, whitebeard
    case roger, doflamingo, heartPirates, blackbeard, revolutionary
    case unknown
}

// GraphQL response wrappers

struct GraphQLResponse<T: Decodable>: Decodable {
    let data: T?
    let errors: [GraphQLError]?
}

struct GraphQLError: Decodable {
    let message: String
}

// Wraps `characters { info { ... } results { ... } }`
struct PaginatedResults<Item: Decodable>: Decodable {
    let info: PaginationInfo?
    let results: [Item]?
}

struct PaginationInfo: Decodable {
    let count: Int?
    let pages: Int?
    let next: Int?
    let prev: Int?
}

//  Query response shapes
// Each wrapper matches the top-level key our query uses.

struct CharactersQueryResponse: Decodable {
    let characters: PaginatedResults<Character>?
}

struct CharacterQueryResponse: Decodable {
    let character: Character?
}

struct DevilFruitsQueryResponse: Decodable {
    let devilFruits: PaginatedResults<DevilFruit>?
}

struct DevilFruitQueryResponse: Decodable {
    let devilFruit: DevilFruit?
}

// Need UIKit for the typeColor extension on DevilFruit

extension DevilFruit {
    // Color the type badge based on what kind of fruit it is
    func typeBadgeColor() -> UIColor {
        let t = (type ?? "").lowercased()
        if t.contains("logia")            { return UIColor(red:0.95, green:0.55, blue:0.20, alpha:1) }
        if t.contains("mythical")         { return UIColor(red:0.80, green:0.35, blue:0.95, alpha:1) }
        if t.contains("zoan")             { return UIColor(red:0.40, green:0.75, blue:0.45, alpha:1) }
        if t.contains("paramecia")        { return UIColor(red:0.40, green:0.65, blue:0.95, alpha:1) }
        return UIColor.systemGray
    }
}
