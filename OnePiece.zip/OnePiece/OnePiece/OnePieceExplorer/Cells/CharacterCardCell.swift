import UIKit

// CharacterCardCell — The Flashy Card for UR rarity
// Premium card with corner badges, name banner, and a foil shimmer for UR cards.
// Updated for the GraphQL data model — no more role field, so the bottom banner
// It shows the character name and crew name only.

final class CharacterCardCell: UICollectionViewCell {

    static let reuseID = "CharacterCardCell"

    // Layers
    private let gradientLayer    = CAGradientLayer()   // crew-colored background
    private let foilLayer        = CAGradientLayer()   // shimmer for UR cards only
    private let bannerFadeLayer  = CAGradientLayer()   // dark fade behind bottom banner

    //  Views
    private let imageView        = UIImageView()
    private let initialsLabel    = UILabel()           // shown until image loads
    private let borderView       = UIView()            // frame around the card

    // Top-left "cost" circle for short bounty
    private let costBadge        = UIView()
    private let costLabel        = UILabel()

    // Top-right rarity stack
    private let rarityValueLabel = UILabel()
    private let rarityTagLabel   = UILabel()

    // Bottom banner — name + crew
    private let bannerContainer  = UIView()
    private let characterTag     = UILabel()
    private let nameLabel        = UILabel()
    private let crewLabel        = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame    = contentView.bounds
        bannerFadeLayer.frame  = contentView.bounds
        foilLayer.frame        = contentView.bounds
        layer.cornerRadius     = 13
        contentView.layer.cornerRadius = 13
        costBadge.layer.cornerRadius   = costBadge.bounds.width / 2
    }

    private func setupViews() {
        layer.masksToBounds = false
        contentView.layer.masksToBounds = true
        contentView.layer.cornerRadius  = 13

        contentView.layer.insertSublayer(gradientLayer, at: 0)

        imageView.contentMode     = .scaleAspectFit
        imageView.clipsToBounds   = true
        imageView.backgroundColor = .clear
        imageView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(imageView)

        initialsLabel.font          = .systemFont(ofSize: 36, weight: .bold)
        initialsLabel.textAlignment = .center
        initialsLabel.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(initialsLabel)

        // Foil shimmer overlay — animated only when card is UR
        foilLayer.colors = [
            UIColor.white.withAlphaComponent(0.0).cgColor,
            UIColor.white.withAlphaComponent(0.28).cgColor,
            UIColor.white.withAlphaComponent(0.0).cgColor,
        ]
        foilLayer.locations  = [-0.5, -0.3, 0]
        foilLayer.startPoint = CGPoint(x: 0, y: 0.2)
        foilLayer.endPoint   = CGPoint(x: 1, y: 0.8)
        foilLayer.opacity    = 0
        contentView.layer.addSublayer(foilLayer)

        // Dark fade behind the bottom banner
        bannerFadeLayer.colors    = [UIColor.clear.cgColor,
                                     UIColor.black.withAlphaComponent(0.92).cgColor]
        bannerFadeLayer.locations = [0.55, 1.0]
        contentView.layer.addSublayer(bannerFadeLayer)

        // Border frame
        borderView.layer.cornerRadius       = 13
        borderView.layer.borderWidth        = 1.8
        borderView.backgroundColor          = .clear
        borderView.isUserInteractionEnabled = false
        borderView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(borderView)

        setupCostBadge()
        setupRarityTag()
        setupBottomBanner()
        applyConstraints()
    }

    private func setupCostBadge() {
        costBadge.layer.borderWidth = 1.5
        costBadge.layer.borderColor = UIColor.white.withAlphaComponent(0.85).cgColor
        costBadge.backgroundColor   = UIColor(red:0.06, green:0.08, blue:0.12, alpha:0.85)
        costBadge.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(costBadge)

        costLabel.font          = .systemFont(ofSize: 9.5, weight: .heavy)
        costLabel.textAlignment = .center
        costLabel.textColor     = .white
        costLabel.adjustsFontSizeToFitWidth = true
        costLabel.minimumScaleFactor        = 0.55
        costLabel.translatesAutoresizingMaskIntoConstraints = false
        costBadge.addSubview(costLabel)
    }

    private func setupRarityTag() {
        rarityValueLabel.font          = .systemFont(ofSize: 16, weight: .heavy)
        rarityValueLabel.textAlignment = .right
        rarityValueLabel.textColor     = .white

        rarityTagLabel.font          = .systemFont(ofSize: 8, weight: .bold)
        rarityTagLabel.textAlignment = .right
        rarityTagLabel.textColor     = UIColor.white.withAlphaComponent(0.65)
        rarityTagLabel.text          = "RARITY"

        [rarityValueLabel, rarityTagLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            contentView.addSubview($0)
        }
    }

    private func setupBottomBanner() {
        bannerContainer.backgroundColor = .clear
        bannerContainer.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(bannerContainer)

        characterTag.font          = .systemFont(ofSize: 7, weight: .heavy)
        characterTag.text          = "— CHARACTER —"
        characterTag.textColor     = UIColor.white.withAlphaComponent(0.5)
        characterTag.textAlignment = .center

        nameLabel.font            = .systemFont(ofSize: 13, weight: .heavy)
        nameLabel.textColor       = .white
        nameLabel.textAlignment   = .center
        nameLabel.adjustsFontSizeToFitWidth = true
        nameLabel.minimumScaleFactor        = 0.6
        nameLabel.numberOfLines             = 1

        crewLabel.font            = .systemFont(ofSize: 8.5, weight: .medium)
        crewLabel.textColor       = UIColor.white.withAlphaComponent(0.55)
        crewLabel.textAlignment   = .center
        crewLabel.adjustsFontSizeToFitWidth = true
        crewLabel.minimumScaleFactor        = 0.7

        [characterTag, nameLabel, crewLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            bannerContainer.addSubview($0)
        }
    }

    private func applyConstraints() {
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),

            initialsLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            initialsLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor, constant: -20),

            borderView.topAnchor.constraint(equalTo: contentView.topAnchor),
            borderView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            borderView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            borderView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),

            costBadge.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 7),
            costBadge.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 7),
            costBadge.widthAnchor.constraint(equalToConstant: 28),
            costBadge.heightAnchor.constraint(equalToConstant: 28),
            costLabel.centerXAnchor.constraint(equalTo: costBadge.centerXAnchor),
            costLabel.centerYAnchor.constraint(equalTo: costBadge.centerYAnchor),
            costLabel.widthAnchor.constraint(equalTo: costBadge.widthAnchor, constant: -4),

            rarityValueLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6),
            rarityValueLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -9),
            rarityTagLabel.topAnchor.constraint(equalTo: rarityValueLabel.bottomAnchor, constant: -2),
            rarityTagLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -9),

            bannerContainer.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 6),
            bannerContainer.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -6),
            bannerContainer.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -7),

            characterTag.topAnchor.constraint(equalTo: bannerContainer.topAnchor),
            characterTag.centerXAnchor.constraint(equalTo: bannerContainer.centerXAnchor),

            nameLabel.topAnchor.constraint(equalTo: characterTag.bottomAnchor, constant: 1),
            nameLabel.leadingAnchor.constraint(equalTo: bannerContainer.leadingAnchor),
            nameLabel.trailingAnchor.constraint(equalTo: bannerContainer.trailingAnchor),

            crewLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 1),
            crewLabel.leadingAnchor.constraint(equalTo: bannerContainer.leadingAnchor),
            crewLabel.trailingAnchor.constraint(equalTo: bannerContainer.trailingAnchor),
            crewLabel.bottomAnchor.constraint(equalTo: bannerContainer.bottomAnchor),
        ])
    }

    func configure(with character: Character) {
        let theme  = character.crewTheme
        let rarity = character.rarity
        let accent = Theme.accentColor(for: theme)

        Theme.applyGradient(to: gradientLayer, theme: theme)
        borderView.layer.borderColor = accent.withAlphaComponent(rarity == .ur ? 1.0 : 0.65).cgColor
        Theme.applyGlow(to: self, rarity: rarity)

        costBadge.layer.borderColor = accent.withAlphaComponent(rarity == .ur ? 1.0 : 0.7).cgColor
        costLabel.text              = character.bountyShort.replacingOccurrences(of: " ฿", with: "")

        let rarityColor = Theme.rarityColor(for: rarity)
        rarityValueLabel.text      = rarity.rawValue
        rarityValueLabel.textColor = rarityColor
        rarityTagLabel.textColor   = rarityColor.withAlphaComponent(0.7)

        nameLabel.text = character.name
        crewLabel.text = character.crewDisplayName.uppercased()

        initialsLabel.text      = initials(for: character.name)
        initialsLabel.textColor = accent.withAlphaComponent(0.4)
        initialsLabel.isHidden  = false

        if rarity == .ur {
            foilLayer.opacity = 1
            startFoilAnimation()
        } else {
            foilLayer.opacity = 0
            foilLayer.removeAllAnimations()
        }

        loadImage(from: character.bestImageURL, accent: accent)
    }

    private func startFoilAnimation() {
        foilLayer.removeAnimation(forKey: "shimmer")
        let anim = CABasicAnimation(keyPath: "locations")
        anim.fromValue   = [-0.6, -0.4, -0.2]
        anim.toValue     = [1.2,   1.4,  1.6]
        anim.duration    = 2.6
        anim.repeatCount = .infinity
        anim.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        foilLayer.add(anim, forKey: "shimmer")
    }

    private var imageTask: URLSessionDataTask?

    private func loadImage(from urlString: String?, accent: UIColor) {
        imageTask?.cancel()
        imageView.image        = nil
        initialsLabel.isHidden = false

        guard let urlString = urlString, let url = URL(string: urlString) else { return }

        if let cached = ImageCache.shared.image(for: url) {
            imageView.image        = cached
            initialsLabel.isHidden = true
            return
        }

        imageTask = URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let image = UIImage(data: data) else { return }
            ImageCache.shared.store(image, for: url)
            DispatchQueue.main.async {
                self?.imageView.image        = image
                self?.initialsLabel.isHidden = true
            }
        }
        imageTask?.resume()
    }

    private func initials(for name: String) -> String {
        name.split(separator: " ").prefix(2).compactMap { $0.first }.map(String.init).joined()
    }

    func snapshotImage() -> UIImage? {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { ctx in
            layer.render(in: ctx.cgContext)
        }
    }

    override var isHighlighted: Bool {
        didSet {
            UIView.animate(withDuration: 0.12, delay: 0,
                           options: [.allowUserInteraction, .curveEaseInOut]) {
                self.transform = self.isHighlighted
                    ? CGAffineTransform(scaleX: 0.93, y: 0.93) : .identity
            }
        }
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        imageTask?.cancel()
        imageView.image        = nil
        initialsLabel.isHidden = false
        nameLabel.text         = nil
        crewLabel.text         = nil
        costLabel.text         = nil
        rarityValueLabel.text  = nil
        foilLayer.removeAllAnimations()
        foilLayer.opacity      = 0
        layer.shadowOpacity    = 0
    }
}

// Image Cache (shared across the app)
final class ImageCache {
    static let shared = ImageCache()
    private init() {}
    private let cache = NSCache<NSURL, UIImage>()
    func image(for url: URL) -> UIImage? { cache.object(forKey: url as NSURL) }
    func store(_ image: UIImage, for url: URL) { cache.setObject(image, forKey: url as NSURL) }
}
