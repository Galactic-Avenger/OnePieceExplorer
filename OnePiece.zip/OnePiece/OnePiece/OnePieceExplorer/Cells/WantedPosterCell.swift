import UIKit

// WantedPosterCell
// One Piece wanted poster styled cell. Replaces the leaderboard's plain table rows
// with proper "WANTED — DEAD OR ALIVE" posters that wouldn't look out of place
// pinned to  anime marine HQ bulletin board.

final class WantedPosterCell: UICollectionViewCell {

    static let reuseID = "WantedPosterCell"

    // Views
    private let paperView      = UIView()      // cream parchment background
    private let wantedLabel    = UILabel()     // "WANTED"
    private let deadOrAlive    = UILabel()     // "DEAD OR ALIVE"
    private let photoFrame     = UIView()      // dark border around character photo
    private let photoImageView = UIImageView()
    private let initialsLabel  = UILabel()     // shown while photo loads
    private let nameLabel      = UILabel()
    private let bountyLabel    = UILabel()     // red ฿ amount
    private let rankLabel      = UILabel()     // "#1 MOST WANTED"
    private let topTape        = UIView()      // little tape strip at top corner
    private let cornerStamp    = UIView()      // subtle marine logo placeholder

    // Paper colors
    private let paperColor = UIColor(red: 0.93, green: 0.86, blue: 0.71, alpha: 1)
    private let inkColor   = UIColor(red: 0.18, green: 0.12, blue: 0.05, alpha: 1)
    private let bountyRed  = UIColor(red: 0.62, green: 0.13, blue: 0.10, alpha: 1)

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        // Drop shadow gives the poster a "lifted off the board" feel
        layer.shadowColor   = UIColor.black.cgColor
        layer.shadowOpacity = 0.35
        layer.shadowOffset  = CGSize(width: 0, height: 3)
        layer.shadowRadius  = 5
        layer.masksToBounds = false
    }

    // Setup
    private func setupViews() {
        contentView.layer.masksToBounds = true

        // Parchment background
        paperView.backgroundColor = paperColor
        paperView.layer.borderWidth = 1.5
        paperView.layer.borderColor = inkColor.withAlphaComponent(0.55).cgColor
        paperView.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(paperView)

        // Small tape strip on the top
        topTape.backgroundColor = UIColor.white.withAlphaComponent(0.55)
        topTape.layer.borderWidth = 0.5
        topTape.layer.borderColor = inkColor.withAlphaComponent(0.2).cgColor
        topTape.transform = CGAffineTransform(rotationAngle: -.pi/24)
        topTape.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(topTape)

        wantedLabel.text          = "WANTED"
        wantedLabel.font          = .systemFont(ofSize: 26, weight: .black)
        wantedLabel.textColor     = inkColor
        wantedLabel.textAlignment = .center
        wantedLabel.adjustsFontSizeToFitWidth = true
        wantedLabel.minimumScaleFactor        = 0.6

        deadOrAlive.text          = "DEAD OR ALIVE"
        deadOrAlive.font          = .systemFont(ofSize: 8, weight: .heavy)
        deadOrAlive.textColor     = inkColor
        deadOrAlive.textAlignment = .center
        deadOrAlive.adjustsFontSizeToFitWidth = true
        deadOrAlive.minimumScaleFactor        = 0.5

        // Photo with a dark border (the "mugshot")
        photoFrame.backgroundColor = inkColor
        photoFrame.layer.borderWidth = 1
        photoFrame.layer.borderColor = inkColor.cgColor

        photoImageView.contentMode   = .scaleAspectFill
        photoImageView.clipsToBounds = true
        photoImageView.backgroundColor = UIColor(red: 0.78, green: 0.70, blue: 0.55, alpha: 1)

        initialsLabel.font          = .systemFont(ofSize: 22, weight: .heavy)
        initialsLabel.textColor     = inkColor.withAlphaComponent(0.5)
        initialsLabel.textAlignment = .center

        nameLabel.font          = .systemFont(ofSize: 13, weight: .heavy)
        nameLabel.textColor     = inkColor
        nameLabel.textAlignment = .center
        nameLabel.adjustsFontSizeToFitWidth = true
        nameLabel.minimumScaleFactor        = 0.5
        nameLabel.numberOfLines = 1

        bountyLabel.font          = .monospacedSystemFont(ofSize: 14, weight: .heavy)
        bountyLabel.textColor     = bountyRed
        bountyLabel.textAlignment = .center
        bountyLabel.adjustsFontSizeToFitWidth = true
        bountyLabel.minimumScaleFactor        = 0.5

        rankLabel.font          = .systemFont(ofSize: 7, weight: .bold)
        rankLabel.textColor     = inkColor.withAlphaComponent(0.6)
        rankLabel.textAlignment = .center

        cornerStamp.backgroundColor    = bountyRed.withAlphaComponent(0.15)
        cornerStamp.layer.cornerRadius = 14
        cornerStamp.layer.borderWidth  = 1
        cornerStamp.layer.borderColor  = bountyRed.withAlphaComponent(0.4).cgColor
        cornerStamp.transform          = CGAffineTransform(rotationAngle: -.pi/14)

        [wantedLabel, deadOrAlive, photoFrame, nameLabel, bountyLabel, rankLabel, cornerStamp].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            paperView.addSubview($0)
        }
        [photoImageView, initialsLabel].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
            photoFrame.addSubview($0)
        }

        applyConstraints()
    }

    private func applyConstraints() {
        NSLayoutConstraint.activate([
            paperView.topAnchor.constraint(equalTo: contentView.topAnchor),
            paperView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            paperView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            paperView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),

            topTape.topAnchor.constraint(equalTo: contentView.topAnchor, constant: -6),
            topTape.centerXAnchor.constraint(equalTo: contentView.centerXAnchor, constant: -10),
            topTape.widthAnchor.constraint(equalToConstant: 50),
            topTape.heightAnchor.constraint(equalToConstant: 14),

            wantedLabel.topAnchor.constraint(equalTo: paperView.topAnchor, constant: 12),
            wantedLabel.leadingAnchor.constraint(equalTo: paperView.leadingAnchor, constant: 10),
            wantedLabel.trailingAnchor.constraint(equalTo: paperView.trailingAnchor, constant: -10),

            deadOrAlive.topAnchor.constraint(equalTo: wantedLabel.bottomAnchor, constant: 0),
            deadOrAlive.leadingAnchor.constraint(equalTo: paperView.leadingAnchor, constant: 12),
            deadOrAlive.trailingAnchor.constraint(equalTo: paperView.trailingAnchor, constant: -12),

            photoFrame.topAnchor.constraint(equalTo: deadOrAlive.bottomAnchor, constant: 8),
            photoFrame.leadingAnchor.constraint(equalTo: paperView.leadingAnchor, constant: 10),
            photoFrame.trailingAnchor.constraint(equalTo: paperView.trailingAnchor, constant: -10),
            photoFrame.heightAnchor.constraint(equalTo: photoFrame.widthAnchor, multiplier: 1.0),

            photoImageView.topAnchor.constraint(equalTo: photoFrame.topAnchor, constant: 3),
            photoImageView.leadingAnchor.constraint(equalTo: photoFrame.leadingAnchor, constant: 3),
            photoImageView.trailingAnchor.constraint(equalTo: photoFrame.trailingAnchor, constant: -3),
            photoImageView.bottomAnchor.constraint(equalTo: photoFrame.bottomAnchor, constant: -3),

            initialsLabel.centerXAnchor.constraint(equalTo: photoImageView.centerXAnchor),
            initialsLabel.centerYAnchor.constraint(equalTo: photoImageView.centerYAnchor),

            nameLabel.topAnchor.constraint(equalTo: photoFrame.bottomAnchor, constant: 7),
            nameLabel.leadingAnchor.constraint(equalTo: paperView.leadingAnchor, constant: 8),
            nameLabel.trailingAnchor.constraint(equalTo: paperView.trailingAnchor, constant: -8),

            bountyLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 3),
            bountyLabel.leadingAnchor.constraint(equalTo: paperView.leadingAnchor, constant: 6),
            bountyLabel.trailingAnchor.constraint(equalTo: paperView.trailingAnchor, constant: -6),

            rankLabel.topAnchor.constraint(equalTo: bountyLabel.bottomAnchor, constant: 1),
            rankLabel.leadingAnchor.constraint(equalTo: paperView.leadingAnchor, constant: 6),
            rankLabel.trailingAnchor.constraint(equalTo: paperView.trailingAnchor, constant: -6),
            rankLabel.bottomAnchor.constraint(lessThanOrEqualTo: paperView.bottomAnchor, constant: -8),

            cornerStamp.bottomAnchor.constraint(equalTo: paperView.bottomAnchor, constant: -8),
            cornerStamp.trailingAnchor.constraint(equalTo: paperView.trailingAnchor, constant: -8),
            cornerStamp.widthAnchor.constraint(equalToConstant: 28),
            cornerStamp.heightAnchor.constraint(equalToConstant: 28),
        ])
    }

    // Configure
    func configure(rank: Int, character: Character) {
        nameLabel.text   = character.name.uppercased()
        bountyLabel.text = character.bountyFormatted

        switch rank {
        case 1:  rankLabel.text = "#1 MOST WANTED"
        case 2:  rankLabel.text = "#2 MOST WANTED"
        case 3:  rankLabel.text = "#3 MOST WANTED"
        default: rankLabel.text = "#\(rank)"
        }

        initialsLabel.text     = character.name.split(separator: " ").prefix(2)
                                     .compactMap { $0.first }.map(String.init).joined()
        initialsLabel.isHidden = false

        loadPhoto(from: character.bestImageURL)
    }

    // Image loading
    private var imageTask: URLSessionDataTask?

    private func loadPhoto(from urlString: String?) {
        imageTask?.cancel()
        photoImageView.image    = nil
        initialsLabel.isHidden  = false

        guard let s = urlString, let url = URL(string: s) else { return }

        if let cached = ImageCache.shared.image(for: url) {
            photoImageView.image    = cached
            initialsLabel.isHidden  = true
            return
        }

        imageTask = URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data = data, let img = UIImage(data: data) else { return }
            ImageCache.shared.store(img, for: url)
            DispatchQueue.main.async {
                self?.photoImageView.image    = img
                self?.initialsLabel.isHidden  = true
            }
        }
        imageTask?.resume()
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        imageTask?.cancel()
        photoImageView.image = nil
        initialsLabel.isHidden = false
        nameLabel.text   = nil
        bountyLabel.text = nil
        rankLabel.text   = nil
    }
}
