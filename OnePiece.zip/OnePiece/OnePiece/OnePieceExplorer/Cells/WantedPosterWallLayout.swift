import UIKit

// WantedPosterWallLayout
// Custom UICollectionViewLayout that arranges poster cells like they're pinned to a bulletin board — slight rotations, top-3 are larger, deliberately
// staggered with overlap so it doesn't feel like a perfect grid.
//
// All position math happens in prepare() and gets cached so scrolling stays smooth.

final class WantedPosterWallLayout: UICollectionViewLayout {

    // Tunables
    private let baseColumns: Int      = 2
    private let horizontalInset: CGFloat = 14
    private let verticalSpacing: CGFloat = 18
    private let baseAspect: CGFloat   = 1.45    // height / width
    private let topRankBoost: CGFloat = 0.25    // #1 gets 25% bigger
    private let secondaryBoost: CGFloat = 0.12  // #2 and #3 get 12% bigger
    private let maxRotation: CGFloat  = 0.06    // ~3.4 degrees in radians

    // Cache
    private var attributesCache: [UICollectionViewLayoutAttributes] = []
    private var totalContentHeight: CGFloat = 0

    override var collectionViewContentSize: CGSize {
        guard let cv = collectionView else { return .zero }
        return CGSize(width: cv.bounds.width, height: totalContentHeight)
    }

    // Prepare
    override func prepare() {
        super.prepare()
        guard let cv = collectionView else { return }
        attributesCache.removeAll()

        let count = cv.numberOfItems(inSection: 0)
        guard count > 0 else { totalContentHeight = 0; return }

        let availableWidth = cv.bounds.width - horizontalInset * 2
        let baseItemWidth  = (availableWidth - 14) / CGFloat(baseColumns)
        let baseItemHeight = baseItemWidth * baseAspect

        var y: CGFloat = 12

        for index in 0..<count {
            // Top 3 ranks get their own larger row, centered
            if index < 3 {
                let scale: CGFloat
                switch index {
                case 0: scale = 1.0 + topRankBoost
                case 1, 2: scale = 1.0 + secondaryBoost
                default: scale = 1.0
                }

                let w = baseItemWidth * scale
                let h = baseItemHeight * scale

                // #1 gets centered solo on its own row, #2 and #3 share next row
                if index == 0 {
                    let x = (cv.bounds.width - w) / 2
                    addAttribute(at: index, frame: CGRect(x: x, y: y, width: w, height: h))
                    y += h + verticalSpacing + 8
                } else if index == 1 {
                    let totalRowWidth = w * 2 + 16
                    let startX = (cv.bounds.width - totalRowWidth) / 2
                    addAttribute(at: index, frame: CGRect(x: startX, y: y, width: w, height: h))
                } else { // index == 2
                    let prevWidth = baseItemWidth * (1.0 + secondaryBoost)
                    let totalRowWidth = prevWidth * 2 + 16
                    let startX = (cv.bounds.width - totalRowWidth) / 2
                    addAttribute(at: index,
                                 frame: CGRect(x: startX + prevWidth + 16, y: y, width: w, height: h))
                    y += h + verticalSpacing + 4
                }
            } else {
                // Regular grid for everyone else (2 per row)
                let posInRow = (index - 3) % baseColumns
                let x = horizontalInset + CGFloat(posInRow) * (baseItemWidth + 14)
                addAttribute(at: index, frame: CGRect(x: x, y: y, width: baseItemWidth, height: baseItemHeight))
                if posInRow == baseColumns - 1 {
                    y += baseItemHeight + verticalSpacing
                }
            }
        }

        // Account for the last row if it wasn't filled
        if let last = attributesCache.last {
            totalContentHeight = last.frame.maxY + 20
        }
    }

    // This helper builds an attribute with the deterministic rotation/zIndex
    private func addAttribute(at index: Int, frame: CGRect) {
        let attr = UICollectionViewLayoutAttributes(forCellWith: IndexPath(item: index, section: 0))
        attr.frame   = frame
        attr.zIndex  = index < 3 ? 10 : index   // top 3 always on top
        attr.transform = rotation(for: index)
        attributesCache.append(attr)
    }

    // Deterministic pseudo-random rotation so the same poster always tilts the same way
    private func rotation(for index: Int) -> CGAffineTransform {
        let seed = sin(Double(index) * 12.9898) * 43758.5453
        let fraction = CGFloat(seed - floor(seed))      // 0..1
        let angle = (fraction - 0.5) * 2 * maxRotation  // -maxRot..+maxRot
        return CGAffineTransform(rotationAngle: angle)
    }

    // Required overrides
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        // Slight padding so rotated cells aren't clipped at the edges of the visible rect
        let inflated = rect.insetBy(dx: -20, dy: -20)
        return attributesCache.filter { $0.frame.intersects(inflated) }
    }

    override func layoutAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        guard indexPath.item < attributesCache.count else { return nil }
        return attributesCache[indexPath.item]
    }

    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        return collectionView?.bounds.width != newBounds.width
    }
}
