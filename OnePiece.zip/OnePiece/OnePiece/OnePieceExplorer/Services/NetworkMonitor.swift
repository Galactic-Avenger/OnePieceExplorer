import Foundation
import Network

//  NetworkMonitor

final class NetworkMonitor {

    static let shared = NetworkMonitor()
    private init() {}

    private let monitor = NWPathMonitor()
    private let queue   = DispatchQueue(label: "com.onepieceexplorer.network")

    private(set) var isConnected: Bool = true

    // Post this notification whenever connectivity changes
    static let connectivityChanged = Notification.Name("NetworkConnectivityChanged")

    func startMonitoring() {
        monitor.pathUpdateHandler = { [weak self] path in
            let connected = path.status == .satisfied
            guard connected != self?.isConnected else { return }
            self?.isConnected = connected
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: NetworkMonitor.connectivityChanged,
                                                object: connected)
            }
        }
        monitor.start(queue: queue)
    }

    func stopMonitoring() {
        monitor.cancel()
    }
}
