import Foundation

// PlistService  (read & write plist)

final class PlistService {

    static let shared = PlistService()
    private init() {}

    // Favorites
    private let favoritesKey  = "favorites"
    private let historyKey    = "searchHistory"
    private let onboardingKey = "hasSeenOnboarding"

    private var plistURL: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return docs.appendingPathComponent("OnePieceExplorer.plist")
    }

    // Read full plist dict
    private func readDict() -> NSMutableDictionary {
        if let dict = NSMutableDictionary(contentsOf: plistURL) { return dict }
        return NSMutableDictionary()
    }

    // Write full plist dict
    private func writeDict(_ dict: NSMutableDictionary) {
        dict.write(to: plistURL, atomically: true)
    }

    // Save favorite character ID
    func saveFavorite(id: Int) {
        let dict = readDict()
        var ids = dict[favoritesKey] as? [Int] ?? []
        if !ids.contains(id) { ids.append(id) }
        dict[favoritesKey] = ids
        writeDict(dict)
    }

    // Remove favorite character ID
    func removeFavorite(id: Int) {
        let dict = readDict()
        var ids = dict[favoritesKey] as? [Int] ?? []
        ids.removeAll { $0 == id }
        dict[favoritesKey] = ids
        writeDict(dict)
    }

    // Load all favorite IDs
    func loadFavoriteIDs() -> [Int] {
        return readDict()[favoritesKey] as? [Int] ?? []
    }

    // Check if character is favorited
    func isFavorite(id: Int) -> Bool {
        return loadFavoriteIDs().contains(id)
    }

    // Toggle favorite
    @discardableResult
    func toggleFavorite(id: Int) -> Bool {
        if isFavorite(id: id) {
            removeFavorite(id: id)
            return false
        } else {
            saveFavorite(id: id)
            return true
        }
    }

    // Search History
    func saveSearchQuery(_ query: String) {
        guard !query.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        let dict = readDict()
        var history = dict[historyKey] as? [String] ?? []
        history.removeAll { $0 == query }   // remove duplicate
        history.insert(query, at: 0)
        if history.count > 10 { history = Array(history.prefix(10)) }  // cap at 10
        dict[historyKey] = history
        writeDict(dict)
    }

    func loadSearchHistory() -> [String] {
        return readDict()[historyKey] as? [String] ?? []
    }

    func clearSearchHistory() {
        let dict = readDict()
        dict.removeObject(forKey: historyKey)
        writeDict(dict)
    }

    //Onboarding flag
    func hasSeenOnboarding() -> Bool {
        return readDict()[onboardingKey] as? Bool ?? false
    }

    func markOnboardingSeen() {
        let dict = readDict()
        dict[onboardingKey] = true
        writeDict(dict)
    }
}
