import Foundation

//  APIService  (GraphQL)
// All requests go to one endpoint as POST with a JSON body containing a `query` string.
// This is much simpler than the old REST per-endpoint approach.

final class APIService: @unchecked Sendable {

    static let shared = APIService()
    private init() {}

    private let endpoint = URL(string: "https://onepieceql.up.railway.app/graphql")!

    // Generic GraphQL POST
    private func performQuery<T: Decodable>(_ query: String,
                                             completion: @escaping @Sendable (Result<T, APIError>) -> Void) {
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        // GraphQL takes a single "query" field with the query string
        let body: [String: Any] = ["query": query]
        guard let data = try? JSONSerialization.data(withJSONObject: body) else {
            completion(.failure(.badURL)); return
        }
        request.httpBody = data

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error { completion(.failure(.networkError(error))); return }
            guard let data = data else { completion(.failure(.noData)); return }
            do {
                let decoded = try JSONDecoder().decode(GraphQLResponse<T>.self, from: data)
                if let errs = decoded.errors, !errs.isEmpty {
                    completion(.failure(.graphQLError(errs.map { $0.message }.joined(separator: "; "))))
                    return
                }
                guard let payload = decoded.data else {
                    completion(.failure(.noData)); return
                }
                completion(.success(payload))
            } catch {
                completion(.failure(.decodingError(error)))
            }
        }.resume()
    }

    // Common character fields — used in most queries
    private let characterFields = """
        id
        englishName
        japaneseName
        bounty
        age
        birthday
        bloodType
        origin
        debut
        devilFruitName
        description
        affiliations
        avatarSrc
    """

    private let devilFruitFields = """
        id
        englishName
        japaneseName
        meaning
        type
        currentOwner
        previousOwner
        description
        usageDebut
        avatarSrc
    """

    // Characters
    func fetchCharacters(page: Int = 1,
                         completion: @escaping @Sendable (Result<[Character], APIError>) -> Void) {
        let query = """
        {
            characters(page: \(page)) {
                info { count pages next prev }
                results { \(characterFields) }
            }
        }
        """
        performQuery(query) { (result: Result<CharactersQueryResponse, APIError>) in
            switch result {
            case .success(let resp): completion(.success(resp.characters?.results ?? []))
            case .failure(let err):  completion(.failure(err))
            }
        }
    }

    // Search by name — the API accepts a `name` filter (we'll send it as a query var)
    func searchCharacters(name: String,
                          completion: @escaping @Sendable (Result<[Character], APIError>) -> Void) {
        // Escape any internal quotes
        let safe = name.replacingOccurrences(of: "\"", with: "\\\"")
        let query = """
        {
            characters(filter: { name: "\(safe)" }) {
                results { \(characterFields) }
            }
        }
        """
        performQuery(query) { (result: Result<CharactersQueryResponse, APIError>) in
            switch result {
            case .success(let resp): completion(.success(resp.characters?.results ?? []))
            case .failure(let err):  completion(.failure(err))
            }
        }
    }

    // Single character by ID
    func fetchCharacter(id: Int,
                        completion: @escaping @Sendable (Result<Character, APIError>) -> Void) {
        let query = """
        {
            character(id: \(id)) { \(characterFields) }
        }
        """
        performQuery(query) { (result: Result<CharacterQueryResponse, APIError>) in
            switch result {
            case .success(let resp):
                if let c = resp.character { completion(.success(c)) }
                else { completion(.failure(.noData)) }
            case .failure(let err): completion(.failure(err))
            }
        }
    }

    // Random — just pick a random page and a random result from it
    func fetchRandomCharacter(completion: @escaping @Sendable (Result<Character, APIError>) -> Void) {
        let randomPage = Int.random(in: 1...8)
        fetchCharacters(page: randomPage) { result in
            switch result {
            case .success(let chars):
                if let pick = chars.randomElement() { completion(.success(pick)) }
                else { completion(.failure(.noData)) }
            case .failure(let err): completion(.failure(err))
            }
        }
    }

    // Fetch many pages and concatenate — used by the leaderboard
    func fetchManyPages(_ pageCount: Int,
                        completion: @escaping @Sendable (Result<[Character], APIError>) -> Void) {
        var all: [Character] = []
        let group = DispatchGroup()
        let lock = NSLock()

        (1...pageCount).forEach { page in
            group.enter()
            fetchCharacters(page: page) { result in
                if case .success(let chars) = result {
                    lock.lock(); all.append(contentsOf: chars); lock.unlock()
                }
                group.leave()
            }
        }
        group.notify(queue: .global()) { completion(.success(all)) }
    }

    // Devil Fruits
    func fetchDevilFruits(page: Int = 1,
                          completion: @escaping @Sendable (Result<[DevilFruit], APIError>) -> Void) {
        let query = """
        {
            devilFruits(page: \(page)) {
                info { count pages next prev }
                results { \(devilFruitFields) }
            }
        }
        """
        performQuery(query) { (result: Result<DevilFruitsQueryResponse, APIError>) in
            switch result {
            case .success(let resp): completion(.success(resp.devilFruits?.results ?? []))
            case .failure(let err):  completion(.failure(err))
            }
        }
    }

    func fetchDevilFruit(id: Int,
                         completion: @escaping @Sendable (Result<DevilFruit, APIError>) -> Void) {
        let query = """
        {
            devilFruit(id: \(id)) { \(devilFruitFields) }
        }
        """
        performQuery(query) { (result: Result<DevilFruitQueryResponse, APIError>) in
            switch result {
            case .success(let resp):
                if let f = resp.devilFruit { completion(.success(f)) }
                else { completion(.failure(.noData)) }
            case .failure(let err): completion(.failure(err))
            }
        }
    }
}

// Errors

enum APIError: Error, LocalizedError {
    case badURL
    case networkError(Error)
    case noData
    case decodingError(Error)
    case graphQLError(String)

    var errorDescription: String? {
        switch self {
        case .badURL:               return "Invalid URL."
        case .networkError(let e):  return "Network error: \(e.localizedDescription)"
        case .noData:               return "No data received."
        case .decodingError(let e): return "Parse error: \(e.localizedDescription)"
        case .graphQLError(let m):  return "API error: \(m)"
        }
    }
}
